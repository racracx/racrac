import React from "react";
import { motion, TargetAndTransition } from "framer-motion";

interface MotionWrapperProps {
  children: React.ReactNode; // เนื้อหาภายใน MotionWrapper
  className?: string; // สำหรับกำหนด className
  style?: React.CSSProperties; // สไตล์เพิ่มเติม
  hoverEffect?: TargetAndTransition; // กำหนดชนิดให้ตรงกับ Framer Motion
  tapEffect?: TargetAndTransition; // กำหนดชนิดให้ตรงกับ Framer Motion
  animateEffect?: TargetAndTransition; // อนิเมชั่นที่ทำงานอัตโนมัติ
  transition?: object; // การตั้งค่า Transition
  onClick?: () => void; // ฟังก์ชันเมื่อกด
}

const MotionWrapper: React.FC<MotionWrapperProps> = ({
  children,
  className = "",
  style = {},
  hoverEffect = { scale: 1.2, color: "#6575F6" }, // ค่าเริ่มต้นเมื่อ Hover
  tapEffect = { scale: 0.8 }, // ค่าเริ่มต้นเมื่อกด
  animateEffect = {}, // ค่าเริ่มต้นอนิเมชั่น
  transition = { type: "spring", stiffness: 300, damping: 20 }, // ค่าเริ่มต้น Transition
  onClick,
}) => {
  return (
    <motion.div
      className={className}
      style={style}
      whileHover={hoverEffect}
      whileTap={tapEffect}
      animate={animateEffect}
      transition={transition}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
};

export default MotionWrapper;
