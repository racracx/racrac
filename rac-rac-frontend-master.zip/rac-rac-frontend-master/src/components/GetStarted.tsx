import React, { useState } from 'react';

import charcterImage from "../assets/images/Landing/start.png";

interface MyModalProps {
  onClose: () => void;
}

const GetStarted: React.FC<MyModalProps> = ({ onClose }) => {
  const [isClicked, setIsClicked] = useState(false);

  const handleParagraphClick = () => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  return (
    <div className='Modal-start rounded-[20px]'>
      <div>
        <div className='center-screen'>
          <div className='screen-inner'>
            <div className='character-area mt-[30px]'>
              <img src={charcterImage} alt="character img" className='m-auto'/>
            </div>
            <div className='text-box mt-[30px] text-[#6575F6] bg-white w-[250px] rounded-[10px] py-[5px] text-center mx-auto mb-[30px]'>
              <button className='get-started' onClick={onClose}>Let’s Get Started!</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetStarted;
