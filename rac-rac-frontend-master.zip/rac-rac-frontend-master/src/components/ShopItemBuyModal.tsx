import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { buyItem } from '../redux/actions';
import blackCat from "../assets/images/Landing/black-cat.png";
import closeButton from "../assets/images/btn-close-round.svg";
import turtle from "../assets/images/Landing/turtle.png";
import rlogoImage from "../assets/images/coin-racrac.svg";
import { Item } from '../assets/products/shopProducts';
import { useDispatch, useSelector } from 'react-redux';
import NotEnoughRACModal from './NotEnoughRACModal';

interface MyModalProps {
  onClose: () => void;
  src: string;
  name: string;
  enough: () => void;
  buyItem: (item: ItemType) => void;
  items: ItemType[];
}

interface ItemType {
  img: string;
  name: string;
  desc: string;
  effect: string;
  price: number;
  lock: number;
  rac: number;
}

const ShopItemBuyModal: React.FC<MyModalProps> = ({ onClose, src, name, enough, items, buyItem }) => {
  const [isClicked, setIsClicked] = useState<boolean>(false);
  const [wear, setWear] = useState<boolean>(false);
  const [item, setItem] = useState<ItemType | null>(null);
  const [showNotEnoughRACModal, setShowNotEnoughRACModal] = useState<boolean>(false);
  const user = useSelector((state: any) => state.userData);
  const dispatch = useDispatch();

  useEffect(() => {
    const foundItem = Item.find(i => i.name === name);
    if (foundItem) {
      setItem(foundItem as ItemType);
    }
  }, [name]);

  const handleParagraphClick = () => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  const buy = () => {
    if (item) {
      const price = item.price;
      if (user.racBalance < price) {
        onClose();
        enough();
      } else {
        buyItem(item);
        dispatch({ type: 'SET_RAC', payload: user.racBalance - price });  
        onClose();
      }
    }
  };

  const closeNotEnoughRACModal = () => {
    setShowNotEnoughRACModal(false);
  };

  if (!item) {
    return <div>Loading...</div>;
  }

  return (
    <div className='Modal-come bg-[#252D52] rounded-[30px] pb-[15px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="" />
      </div>
      <div className='center-img mt-[42px] mb-[10px]'>
        <img src={src} alt="tonIcon Img" className='m-auto w-[130px]'/>
      </div>
      <div className='text-area mt-[20px]'>
        <div className='text-[#5C647F] text-bold text-[20px] text-center'>{item.name}</div>
        <div className='text-white text-[15px] mt-[20px] text-center px-[30px]'>{item.desc}</div>
        <div className='text-white text-bold text-[15px] mt-[10px] text-center mb-[10px]'>{item.effect}</div>
      </div>
      <button className='w-[80%] py-[10px] text-[20px] rounded-lg ml-[10%] mt-[14px] mb-[20px] bg-[#EA56D1] flex text-white justify-center' onClick={buy}>
        <div className='text-white text-[18px]'>
          {item.price} 
        </div>
        <img src={rlogoImage} className='ml-[8px] w-[25px]' alt="" />
      </button>
    </div>
  );
};

const mapStateToProps = (state: { items: ItemType[] }) => ({
  items: state.items,
});

const mapDispatchToProps = {
  buyItem: (item: ItemType) => ({ type: 'BUY_ITEM', payload: item }),
};

export default connect(mapStateToProps, mapDispatchToProps)(ShopItemBuyModal);
