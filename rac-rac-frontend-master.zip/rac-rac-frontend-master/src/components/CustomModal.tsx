import React from 'react';
import ReactDOM from 'react-dom';
import { Modal, ModalBody, ModalHeader, ModalFooter, Button } from 'reactstrap';

// Create a Portal component
const Portal: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const modalRoot = document.getElementById('tc-widget-root') as HTMLElement | null;

  if (!modalRoot) {
    console.error("Modal root element not found");
    return null; // Return null if modalRoot is not found
  }

  return ReactDOM.createPortal(children, modalRoot);
};

// Your Modal component
interface CustomModalProps {
  isOpen: boolean;
  toggle: () => void;
  modalType: string;
  children: React.ReactNode;
}

const CustomModal: React.FC<CustomModalProps> = ({ isOpen, toggle, modalType, children }) => {
  return (
    <Portal>
      <Modal
        isOpen={isOpen}
        toggle={toggle}
        className={modalType === 'raffle' || modalType === 'started' ? 'reward-modal' : 'come-modal'}
        centered
      >
        <ModalBody>{children}</ModalBody>
      </Modal>
    </Portal>
  );
};

export default CustomModal;
