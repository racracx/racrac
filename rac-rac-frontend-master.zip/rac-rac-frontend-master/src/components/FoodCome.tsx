import React from 'react';

import foodcome from "../assets/images/Landing/Do not shot this again.png";
import closeButton from "../assets/images/btn-close-round.svg";

interface MyModalProps {
  onClose: () => void;
}

const FoodCome: React.FC<MyModalProps> = ({ onClose }) => {
  return (
    <div className='Modal-come rounded-[30px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="Close" />
      </div>
      <div className='center-img'>
        <img src={foodcome} alt="Food Icon" className='m-auto rounded-lg'/>
      </div>
    </div>
  );
};

export default FoodCome;
