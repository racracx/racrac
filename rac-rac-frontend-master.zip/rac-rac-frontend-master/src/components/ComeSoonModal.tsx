import React, { useState } from 'react';

import blackCat from "../assets/images/Landing/black-cat.png";
import closeButton from "../assets/images/Landing/close-button.png";
import raffleTitle from "../assets/images/Landing/raffle-title.png";
import grandTitle from "../assets/images/Landing/grand-title.png";

interface MyModalProps {
  onClose: () => void;
}

const ComeSoonModal: React.FC<MyModalProps> = ({ onClose }) => {
  const [isClicked, setIsClicked] = useState<boolean>(false);

  const handleParagraphClick = (): void => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  return (
    <div className='Modal-come bg-[#252D52] rounded-[30px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="Close" />
      </div>
      <div className='center-img mt-[70px]'>
        <img src={blackCat} alt="Black Cat Icon" className='m-auto'/>
      </div>
      <h2 className='text-white text-center mt-[30px] text-[20px]' style={{ fontFamily: 'Caros Bold' }}>Coming Soon...</h2>
      <h3 className='text-white text-center mt-[10px] mb-[40px] text-[16px]'>Let’s wait here together.</h3>
    </div>
  );
};

export default ComeSoonModal;
