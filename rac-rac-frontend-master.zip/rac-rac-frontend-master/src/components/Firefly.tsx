import { motion } from "framer-motion";
import firefly from "../assets/images/Character/firefly.png";

const Firefly = () => {
  const fireflies = Array.from({ length: 1 }); // สร้างหิ่งห้อย 20 ตัว
  const randomInRange = (min: number, max: number) =>
    Math.random() * (max - min) + min;

  const generateRandomPosition = () => ({
    x: randomInRange(-200, 200), // ตำแหน่งสุ่มในแกน X (-150 ถึง 150)
    y: randomInRange(-200, 200), // ตำแหน่งสุ่มในแกน Y (-150 ถึง 150)
  });

  const fireflyAnimation = {
    initial: generateRandomPosition(),
    animate: {
      ...generateRandomPosition(),
      opacity: [0, 1, 0], // แสงกระพริบ (0 -> 1 -> 0)
      scale: [0, 1, 0], // ขยาย-ย่อ (0.5 -> 1 -> 0.5)
      transition: {
        duration: randomInRange(3, 5), // ความเร็วสุ่ม (2-5 วินาที)
        repeat: Infinity, // ทำซ้ำไม่มีที่สิ้นสุด
      },
    },
  };

  return (
    // <div
    //   style={{
    //     width: "300px",
    //     height: "400px",
    //     backgroundColor: "transparent",
    //     overflow: "hidden",
    //     position: "absolute",
    //     justifyContent: "center",
    //   }}
    // >

    // </div>
    <motion.img
      src={firefly}
      alt="firefly"
      style={{
        position: "absolute",
        top: "30px",
        left: "45px",
        width: "200px",
        zIndex: 8,
        transformOrigin: "center",
      }}
      variants={fireflyAnimation}
      animate={"animate"}
    />
  );
};

export default Firefly;
