import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import styled from 'styled-components';

// Assets
import coinRacRac from '../assets/images/coin-racrac.svg';
import coinTon from '../assets/images/coin-ton.svg';
import imgSetting from '../assets/images/img-setting.svg';
import logoRacRac from '../assets/images/logo-racrac.svg';

// Styled Components
const HeaderContainer = styled.header`
  align-items: center;
  background-color: #0D0D0D;
  display: flex;
  justify-content: space-between;
  position: sticky;
  z-index: 100;
`;

const LandingTitle = styled.div`
  width: 100%;
`;

const TopSection = styled.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
  margin-bottom: 23px;
`;

const StatsArea = styled.div`
  display: flex;
  gap: 16px;
`;

const ScoreBox = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 6px 11px;
  border-radius: 10px;
  background-color: #6575F626;
`;

const BalanceText = styled.div<{ variant?: 'racrac' | 'ton' }>`
  font-family: 'Caros Regular', sans-serif;
  font-size: 15px;
  margin-left: auto;
  color: ${props => props.variant === 'racrac' ? '#6575F6' : '#FFFFFF'};
`;

const Icon = styled.i`
  display: flex;
  align-items: center;
  margin-right: 8px;
  
  img {
    width: 24px;
    height: 24px;
  }
`;
const Header: React.FC = () => {
    const user = useSelector((state: any) => state.userData);
    useEffect(() => {}, [user]);
  
    return (
      <HeaderContainer>
        <LandingTitle>
          <TopSection>
            <img src={logoRacRac} alt="racracIcon Img" />
            <img src={imgSetting} alt="setting Img" />
          </TopSection>
          <StatsArea>
            <ScoreBox>
              <Icon>
                <img src={coinRacRac} alt="tonIcon Img" />
              </Icon>
              <BalanceText variant="racrac">
                {user.racBalance ?? "-"}
              </BalanceText>
            </ScoreBox>
            <ScoreBox>
              <Icon>
                <img src={coinTon} alt="tonIcon Img" />
              </Icon>
              <BalanceText variant="ton">
                {user.tonBalance ?? "-"}
              </BalanceText>
            </ScoreBox>
          </StatsArea>
        </LandingTitle>
      </HeaderContainer>
    );
  };

export default Header;