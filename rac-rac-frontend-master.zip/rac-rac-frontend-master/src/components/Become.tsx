import React, { useState } from "react";
import { motion } from "framer-motion";

import blackCat from "../assets/images/Landing/black-cat.png";
import closeButton from "../assets/images/Landing/close-button.png";
import become from "../assets/images/Landing/become.png";

interface MyModalProps {
  onClose: () => void;
}

const Become: React.FC<MyModalProps> = ({ onClose }) => {
  const [isClicked, setIsClicked] = useState<boolean>(false);

  const handleParagraphClick = (): void => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  return (
    <div className="Modal-come bg-[#252D52] rounded-[30px]">
      {/* Close Button */}
      <motion.div
        className="absolute right-[20px] top-[20px]"
        onClick={onClose}
        whileHover={{
          scale: 1.2, // ขยายเล็กน้อยเมื่อ Hover
          rotate: 10, // หมุนเล็กน้อยเมื่อ Hover
        }}
        whileTap={{
          scale: 0.9, // ย่อเล็กน้อยเมื่อกด
        }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 20,
        }}
      >
        <img src={closeButton} alt="Close" />
      </motion.div>

      {/* Main Image */}
      <img src={become} alt="Become Icon" className="m-auto rounded-[20px]" />

      {/* Buttons */}
      <div className="button-div absolute top-[40%] w-full px-[20px]">
        {/* Link Button */}
        <motion.button
          className="bg-[#1C223F] text-white py-[7px] w-full rounded-lg"
          onClick={onClose}
          whileHover={{
            scale: 1.1, // ขยายเล็กน้อยเมื่อ Hover
            backgroundColor: "#6575F6", // เปลี่ยนสีพื้นหลัง
          }}
          whileTap={{
            scale: 0.95, // ย่อเล็กน้อยเมื่อกด
          }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20,
          }}
        >
          Link
        </motion.button>

        {/* Add Button */}
        <motion.button
          className="bg-white text-black py-[10px] w-full rounded-lg mt-[10px]"
          onClick={onClose}
          whileHover={{
            scale: 1.1,
            backgroundColor: "#EAEAEA", // เปลี่ยนสีพื้นหลังเมื่อ Hover
          }}
          whileTap={{
            scale: 0.95,
          }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20,
          }}
        >
          Add
        </motion.button>
      </div>
    </div>
  );
};

export default Become;
