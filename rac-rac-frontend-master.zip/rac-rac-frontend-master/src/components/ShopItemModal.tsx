import React, { useState } from 'react';
import blackCat from "../assets/images/Landing/black-cat.png";
import closeButton from "../assets/images/btn-close-round.svg";
import turtle from "../assets/images/Landing/turtle.png";
import { Item } from '../assets/products/shopProducts';
import { useDispatch, useSelector } from 'react-redux';

interface MyModalProps {
  onClose: () => void;
  itemStatsShow: boolean;
  item: ItemType;
}

interface ItemType {
  img: string;
  name: string;
  desc: string;
  effect: string;
  price: number;
  lock: number;
  rac: number;
}

const ShopItemModal: React.FC<MyModalProps> = ({ onClose, itemStatsShow, item }) => {
  const [isClicked, setIsClicked] = useState<boolean>(false);
  const [wear, setWear] = useState<boolean>(false);
  const dispatch = useDispatch();
  const user = useSelector((state: any) => state.userData);

  const handleParagraphClick = () => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  const handleWearClick = () => {
    setWear(!wear);
    if(['Last Autumn Leaf', 'Departure Stick', 'Origami Bird', 'Wishworn Candle'].indexOf(item.name) !== -1) {
      dispatch({ type: 'SET_HAT', payload: ['Last Autumn Leaf', 'Departure Stick', 'Origami Bird', 'Wishworn Candle'].indexOf(item.name) + 1 });  
    }
    else if(['Little Hero’s Shirt', 'Kind Girl’s Shirt', 'RACRAC Tee'].indexOf(item.name) !== -1) {
      dispatch({ type: 'SET_SHIRT', payload: ['Little Hero’s Shirt', 'Kind Girl’s Shirt', 'RACRAC Tee'].indexOf(item.name) + 1 });  
    } else if(item.name === 'Sunny Shell Charm') {
      dispatch({ type: 'SET_NECK', payload: 1 });  
    }
  };

  return (
    <div className='Modal-come bg-[#252D52] rounded-[30px] pb-[15px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="" />
      </div>
      <div className='center-img mt-[50px] mb-[10px]'>
        <img src={item.img} alt="tonIcon Img" className='m-auto w-[150px]'/>
      </div>
      <div className='text-area'>
        <div className='text-[#5C647F] text-[22px] text-center'>{item.name}</div>
        <div className='text-white text-[17px] text-center px-[30px]'>{item.desc}</div>
        <div className='text-white text-bold text-[18px] mt-[10px] text-center mb-[10px]'>{item.effect}</div>
      </div>
      <button className='war-btn w-[80%] py-[10px] rounded-lg ml-[10%]' style={{background : !wear ? 'white' : '#6575F626', color: !wear ? 'black' : 'white'}} onClick={handleWearClick}>{!wear ? 'Wear' : 'Wearing'}</button>
    </div>
  );
};

export default ShopItemModal;
