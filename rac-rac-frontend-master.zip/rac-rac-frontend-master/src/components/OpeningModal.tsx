import React, { useState } from 'react';

import modalImage from "../assets/images/Landing/charcter-welcome.png";
import raffleTitle from "../assets/images/Landing/raffle-title.png";
import grandTitle from "../assets/images/Landing/grand-title.png";

interface MyModalProps {
  onClose: () => void;
}

const MyModal: React.FC<MyModalProps> = ({ onClose }) => {
  const [isClicked, setIsClicked] = useState<boolean>(false);

  const closeModal = (): void => {
    onClose();
  };

  const handleParagraphClick = (): void => {
    setIsClicked((prevState) => !prevState);
  };

  return (
    <div className='Modal-opening rounded-[20px]'>
      <div className='title-area'>
        <h2><img src={raffleTitle} alt="" className='m-auto'/></h2>
        <img className='m-auto' src={grandTitle} alt="" />
      </div>
      <div className='center-img'>
        <img src={modalImage} alt="tonIcon Img" />
        <button onClick={onClose} className='win-btn'>Let's Win!</button>
      </div>
      <div className='footer'>
        <p onClick={handleParagraphClick} style={{ color: isClicked ? '#6575F6' : '#BEBEBE' }}>
          <i>
            <svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="11.5013" cy="11.5" r="11.5" fill="#D9D9D9" style={{fill: isClicked ? '#6575F6' : '#BEBEBE', color: '(display-p3 0.8510 0.8510 0.8510)', fillOpacity: '1'}} />
              <path d="M5.50134 12.2426L9.2587 16L17.0013 8" stroke="white" style={{ stroke: 'white', strokeOpacity: '1' }} strokeWidth="3" strokeLinecap="round" />
            </svg>
          </i>
          Do not show this again
        </p>
        <button onClick={closeModal}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fillRule="evenodd" clipRule="evenodd" d="M1.95235 0.334735C1.50604 -0.111578 0.782422 -0.111578 0.336108 0.334735C-0.110205 0.781049 -0.110205 1.50467 0.336108 1.95098L6.38513 8L0.336109 14.049C-0.110205 14.4953 -0.110205 15.219 0.336109 15.6653C0.782421 16.1116 1.50604 16.1116 1.95235 15.6653L8.00137 9.61624L14.0504 15.6653C14.4967 16.1116 15.2203 16.1116 15.6666 15.6653C16.113 15.219 16.113 14.4953 15.6666 14.049L9.61762 8L15.6666 1.95098C16.113 1.50467 16.113 0.781049 15.6666 0.334735C15.2203 -0.111578 14.4967 -0.111578 14.0504 0.334735L8.00137 6.38376L1.95235 0.334735Z" fill="#6575F6" style={{fill:'#6575F6',color:'(display-p3 0.9804 0.3608 0.3608)',fillOpacity: '1'}} />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default MyModal;
