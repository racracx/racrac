import React, { useState } from "react";
import { easeInOut, motion } from "framer-motion";
import { Scale } from "lucide-react";

const randomInRange = (min: number, max: number) =>
  Math.random() * (max - min) + min;
// Variants สำหรับแต่ละส่วน
export const tailVariants = {
  idle: {
    ease: easeInOut,
    rotate: [0, randomInRange(-5, 0), randomInRange(0, -5), 0],
    rotateY: [0, 0, 0, 0, 0],
    transition: {
      duration: randomInRange(3, 5),
      repeat: Infinity,
      repeatDelay: 0,
    },
  },
  angry: {
    ease: easeInOut,
    rotateY: [
      0,
      randomInRange(0, 360),
      randomInRange(0, 360),
      randomInRange(0, 360),
      0,
    ],
    // rotate: [0, randomInRange(-5, 0), randomInRange(0, -5), 0],
    transition: {
      duration: randomInRange(8, 10),
      repeat: Infinity,
      repeatDelay: 0,
    },
  },
  bye: {
    ease: easeInOut,
    rotate: [0, 10, -10, 10, -10, 10, 0],
    rotateY: [0, 0, 0, 0, 0],
    transition: {
      duration: randomInRange(2, 3),
      times: [0, 0.1, 0.1, 0.1, 1],
      repeat: Infinity,
      repeatDelay: 0,
    },
  },
  sad: {
    ease: easeInOut,
    rotate: [0, randomInRange(-5, 0), randomInRange(0, -5), 0],
    rotateY: [0, 0, 0, 0, 0],
    transition: {
      duration: randomInRange(1, 2),
      repeat: Infinity,
      repeatDelay: 0,
    },
  },
  excited: {
    ease: easeInOut,
    rotate: [0, 10, -10, 10, -10, 10, 0],
    rotateY: [0, 0, 0, 0, 0],
    transition: {
      duration: randomInRange(2, 3),
      times: [0, 0.1, 0.1, 0.1, 1],
      repeat: Infinity,
      repeatDelay: 0,
    },
  },
};

export const leftHandVariants = {
  idle: {
    rotateX: [0, 0, 0, 0, 0],
    rotate: [100, randomInRange(95, 105), randomInRange(95, 105), 100],
    transition: { duration: randomInRange(3, 5), repeat: Infinity },
  },
  angry: {
    rotateX: [0, 0, 0, 0, 0],
    rotate: [100, randomInRange(95, 105), randomInRange(95, 105), 100],
    transition: { duration: randomInRange(3, 5), repeat: Infinity },
  },
  bye: {
    rotateX: [-180, -180, -180],
    rotate: [200, 160, 200],
    transition: {
      duration: randomInRange(0.5, 0.5),
      repeat: Infinity,
      // times: [0,0],
    },
  },
  sad: {
    left: ["75px", "75px", "75px"],
    zIndex: 10,
    rotateX: [0, 0, 0, 0, 0],
    rotate: [10, 20, 10],
    transition: { duration: randomInRange(0.5, 1), repeat: Infinity },
  },
  excited: {
    rotateX: [-180, -180, -180],
    rotate: [200, 160, 200],
    transition: {
      duration: randomInRange(0.5, 0.5),
      repeat: Infinity,
      // times: [0,0],
    },
  },
};

export const rightHandVariants = {
  idle: {
    rotateX: [0, 0, 0, 0, 0],
    rotate: [-100, randomInRange(-95, -105), randomInRange(-95, -105), -100],
    transition: { duration: randomInRange(3, 5), repeat: Infinity },
  },
  angry: {
    rotateX: [0, 0, 0, 0, 0],
    rotate: [-100, randomInRange(-95, -105), randomInRange(-95, -105), -100],
    transition: { duration: randomInRange(3, 5), repeat: Infinity },
  },
  bye: {
    rotateX: [0, 0, 0, 0, 0],
    rotate: [-100, randomInRange(-95, -105), randomInRange(-95, -105), -100],
    transition: { duration: randomInRange(3, 5), repeat: Infinity },
  },
  sad: {
    rotateX: [0, 0, 0, 0, 0],
    top: ["110px", "110px", "110px"],
    left: ["130px", "130px", "130px"],
    zIndex: 10,
    rotate: [0, -10, 0],
    transition: { duration: randomInRange(0.5, 1), repeat: Infinity },
  },
  excited: {
    rotateX: [180, 180, 180],
    rotate: [200, 160, 200],
    transition: {
      duration: randomInRange(0.5, 0.5),
      repeat: Infinity,
      // times: [0,0],
    },
  },
};

export const headVariants = {
  idle: {
    rotate: [0, -5, 5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  angry: {
    y: [0, 3, -3, 3, -3, 3, -3, 0],
    rotateX: [0, 10, 0],
    rotate: [0, 5, -5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  bye: {
    rotate: [-5, 5, -5, 5, -5, 5, -5, 5, -5, 5, -5, 5, -5],
    transition: {
      duration: 5,
      repeat: Infinity,
    },
  },
  sad: {
    y: [0, 3, 0, 3, 0, 3, 0, 3, 0],
    rotate: [0, -5, 5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  excited: {
    x: [-3, 3, -3],
    rotate: [-5, 5, -5],
    transition: {
      duration: 1,
      repeat: Infinity,
    },
  },
};
export const eyeVariants = {
  idle: {
    rotateX: [0, 0, 0],
    y: [0, 0, 0],
    rotate: [0, -5, 5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  angry: {
    y: [0, 3, -3, 3, -3, 3, -3, 0],
    rotateX: [0, 10, 0],
    rotate: [0, 5, -5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  bye: {
    y: [0, 0, 0, 0, 0, 0, -30, 0],
    rotateX: [0, 0, 0, 0, 0, 0, 90, 0],
    rotate: [-5, 5, -5, 5, -5, 5, -5, 5, -5, 5, -5, 5, -5],
    transition: {
      duration: 5,
      repeat: Infinity,
      //   times: [1, 1, 1, 1, 1, 0.1, 1, 1],
    },
  },
  sad: {
    y: [0, 3, 0, 3, 0, 3, 0, 3, 0],
    rotateX: [0, 0, 0],
    rotate: [0, -5, 5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  excited: {
    x: [-3, 3, -3],
    rotate: [-5, 5, -5],
    transition: {
      duration: 1,
      repeat: Infinity,
    },
  },
};
export const mouthVariants = {
  idle: {
    rotate: [0, -5, 5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  angry: {
    y: [0, 3, -3, 3, -3, 3, -3, 0],
    rotateX: [0, 10, 0],
    rotate: [0, 5, -5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  bye: {
    rotate: [-5, 5, -5, 5, -5, 5, -5, 5, -5, 5, -5, 5, -5],
    transition: {
      duration: 5,
      repeat: Infinity,
    },
  },
  sad: {
    y: [0, 3, 0, 3, 0, 3, 0, 3, 0],
    rotate: [0, -5, 5, 0],
    transition: { duration: 5, repeat: Infinity },
  },
  excited: {
    x: [-3, 3, -3],
    rotate: [-5, 5, -5],
    transition: {
      duration: 1,
      repeat: Infinity,
    },
  },
};
export const bodyVariants = {
  // idle: {
  //   rotate: [0, randomInRange(-5, 5), randomInRange(-5, -5), 0],
  //   transition: { duration: randomInRange(4, 5), repeat: Infinity },
  // },
  // bye: {
  //   rotate: [-5, 5, -5],
  //   transition: {
  //     duration: randomInRange(0.8, 1),
  //     repeat: Infinity,
  //   },
  // },
  // sad: {
  //   y: [0, 3, 0, 3, 0, 3, 0, 3, 0],
  //   rotate: [0, randomInRange(-5, 5), randomInRange(-5, -5), 0],
  //   transition: { duration: randomInRange(4, 5), repeat: Infinity },
  // },
  excited: {
    // x: [-3, 3, -3],
    // rotate: [-5, 5, -5],
    scaleY: [1, 0.9, 1],
    transition: {
      duration: randomInRange(0.8, 1),
      repeat: Infinity,
    },
  },
};

export const barrierVariants = {
  idle: {
    scale: [1, 1.5], // ขยายจาก 1 ไป 1.3
    opacity: [0, 0.8, 0], // เฟดจาก 1 ไป 0
    transition: {
      type: "tween", // ใช้สปริงเพื่อให้สมูท
      // damping: 15, // ลดแรงกระแทก (ยิ่งสูง ยิ่งสมูท)
      // stiffness: 50, // ความแข็งของสปริง (เพิ่มความเร็ว)
      duration: 3, // กำหนดเวลาอนิเมชัน (วินาที)
      repeat: Infinity, // ทำวนซ้ำไปเรื่อยๆ
      // repeatType: "reverse", // กลับไป-กลับมา
    },
  },
  idle2: {
    scale: [1, 1.5], // ขยายจาก 1 ไป 1.3
    opacity: [0, 0.8, 0], // เฟดจาก 1 ไป 0
    transition: {
      type: "tween", // ใช้สปริงเพื่อให้สมูท
      // damping: 15, // ลดแรงกระแทก (ยิ่งสูง ยิ่งสมูท)
      // stiffness: 50, // ความแข็งของสปริง (เพิ่มความเร็ว)
      duration: 5, // กำหนดเวลาอนิเมชัน (วินาที)
      repeat: Infinity, // ทำวนซ้ำไปเรื่อยๆ
      // repeatType: "reverse", // กลับไป-กลับมา
    },
  },
  idle3: {
    scale: [1, 1.5], // ขยายจาก 1 ไป 1.3
    opacity: [0, 0.8, 0], // เฟดจาก 1 ไป 0
    transition: {
      type: "tween", // ใช้สปริงเพื่อให้สมูท
      // damping: 15, // ลดแรงกระแทก (ยิ่งสูง ยิ่งสมูท)
      // stiffness: 50, // ความแข็งของสปริง (เพิ่มความเร็ว)
      duration: 7, // กำหนดเวลาอนิเมชัน (วินาที)
      repeat: Infinity, // ทำวนซ้ำไปเรื่อยๆ
      // repeatType: "reverse", // กลับไป-กลับมา
    },
  },
};
