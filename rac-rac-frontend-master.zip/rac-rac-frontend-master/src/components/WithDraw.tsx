import React, { useState } from 'react';

import blackCat from "../assets/images/Landing/RAConTON 1.png";
import closeButton from "../assets/images/btn-close-round.svg";
import tonIconImage from "../assets/images/Landing/ton-icon.png";

interface MyModalProps {
  onClose: () => void;
}

const WithDraw: React.FC<MyModalProps> = ({ onClose }) => {
  const [isClicked, setIsClicked] = useState(false);

  const handleParagraphClick = () => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  return (
    <div className='Modal-come bg-[#252D52] rounded-[30px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="" />
      </div>
      <div className='center-img mt-[40px]'>
        <img src={blackCat} alt="tonIcon Img" className='m-auto'/>
      </div>
      <h2 className='text-white text-center mt-[20px] text-[20px] mb-[20px]' style={{ fontFamily: 'Caros Bold' }}>Withdraw 5 TON now</h2>
      <div className='flex justify-between px-[30px] mb-[30px]'>
        <button className='px-[15px] py-[3px] text-white bg-[#1C223F] rounded-lg' onClick={onClose}>No, thanks</button>
        <button className='px-[15px] py-[5px] bg-white flex rounded-lg text-[#0098EA]' onClick={() => onClose()}><img src={tonIconImage} alt="" /><span className='mt-[0px] pl-[5px] text-[#0098EA] text-[15px]'>5</span><span className='mt-[5px] pl-[15px] text-[#0098EA] text-[10px]'>+30 Fee</span></button>
      </div>
    </div>
  );
};

export default WithDraw;
