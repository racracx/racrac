interface NavIconProps {
  activeSrc: string;
  isActive: boolean;
  src: string;
}

const NavIcon: React.FC<NavIconProps> = ({
  activeSrc,
  isActive,
  src,
}) => {
  return (
    <img
      alt="Navigation Icon" 
      src={isActive ? activeSrc : src}
    />
  );
};

export default NavIcon;