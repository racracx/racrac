import React from "react";
import { motion } from "framer-motion";

const ClaimButton = ({
  isClaimAnimation = false, // สถานะที่ควบคุมสีของปุ่ม
  onClick = () => {}, // ฟังก์ชันเมื่อกดปุ่ม
  text = "Claim!", // ข้อความปุ่ม
  style = {}, // สไตล์เพิ่มเติมที่ส่งเข้ามา
}) => {
  return (
    <motion.button
      className="px-[15px] rounded-lg py-[3px] text-sm mt-[5px]"
      style={{
        // background: isClaimAnimation ? "#1A2035" : "#EA56D1",
        color: isClaimAnimation ? "#6366f1" : "#6366f1",
        boxShadow: isClaimAnimation ? "0 0 10px #6366f1" : "0 0 10px #6366f1", // เพิ่มเงา
        ...style, // รวมสไตล์ที่ส่งเข้ามา
      }}
      onClick={onClick}
      whileHover={{
        scale: 1.2, // ขยายปุ่มให้ใหญ่ขึ้น
        rotate: 5, // หมุนเล็กน้อย
        boxShadow: "0 0 30px #FF69B4", // เพิ่มแสงเงา
        textShadow: "0 0 5px #fff", // เพิ่มแสงให้ข้อความ
      }}
      whileTap={{
        scale: 0.9, // ลดขนาดปุ่มเล็กน้อย
        rotate: -5, // หมุนกลับ
      }}
      animate={{
        y: [0, isClaimAnimation ? 0 : -3, 0], // เด้งขึ้นลง
        transition: {
          repeat: Infinity, // วนซ้ำ
          duration: 1, // ระยะเวลาหนึ่งรอบ
          ease: "easeInOut", // การเคลื่อนไหวแบบนุ่มนวล
        },
      }}
      transition={{
        type: "spring", // ใช้ spring เพื่อการเคลื่อนไหวที่นุ่มนวล
        stiffness: 300,
        damping: 20,
      }}
    >
      {text}
    </motion.button>
  );
};

export default ClaimButton;
