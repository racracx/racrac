import React, { useState } from 'react';

import blackCat from "../assets/images/Landing/Not Enough 1.png";
import closeButton from "../assets/images/btn-close-round.svg";

interface MyModalProps {
  onClose: () => void;
  selectRac: () => void;
}

const NotEnoughRACModal: React.FC<MyModalProps> = ({ onClose, selectRac }) => {
  const [isClicked, setIsClicked] = useState(false);

  const handleParagraphClick = () => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  return (
    <div className='Modal-come bg-[#252D52] rounded-[30px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="Close" />
      </div>
      <div className='center-img mt-[70px]'>
        <img src={blackCat} alt="Black Cat Icon" className='m-auto'/>
      </div>
      <h2 className='text-white text-center mt-[20px] text-[20px] font-bold' style={{ fontFamily: 'Caros Bold' }}>Not Enough Rac...</h2>
      <button className='w-[80%] py-[10px] text-[20px] rounded-lg ml-[10%] bg-white text-black flex justify-center mb-[20px] mt-[20px]' onClick={selectRac}>
        Get Rac
      </button>
    </div>
  );
};

export default NotEnoughRACModal;
