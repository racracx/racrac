// ***ตารางค่าของ transition***
// duration	ระยะเวลาของแอนิเมชัน (วินาที).	undefined
// delay	หน่วงเวลาก่อนเริ่มแอนิเมชัน (วินาที).	0
// type	ประเภทของแอนิเมชัน ("tween", "spring", "inertia").	"tween"
// ease	รูปแบบการเร่ง/ชะลอ ("easeIn", "easeOut", "easeInOut", "linear", Custom Array).	"easeOut"
// stiffness	ความแข็งของสปริง (เฉพาะ spring).	100
// damping	ความต้านของสปริง (เฉพาะ spring).	10
// repeat	จำนวนรอบที่วนซ้ำ (ตั้งเป็น Infinity เพื่อวนไม่สิ้นสุด).	0
// repeatType	รูปแบบการวนซ้ำ ("loop", "reverse", "mirror").	"loop"
// repeatDelay	หน่วงเวลาแต่ละรอบที่วนซ้ำ (วินาที).	0
// times	ระบุจุดเวลาเฉพาะใน Keyframes (ค่าระหว่าง 0 ถึง 1).	undefined

// ***ตารางค่าหลักที่ควบคุมการเคลื่อนที่***
// x	เคลื่อนที่ในแกน X (แนวนอน).	100 (พิกเซล), "-50%"
// y	เคลื่อนที่ในแกน Y (แนวตั้ง).	50 (พิกเซล), "20%"
// z	เคลื่อนที่ในแกน Z (เชิงลึก, 3D).	100
// translateX	การเลื่อนตำแหน่งในแกน X (เหมือน x).	100px
// translateY	การเลื่อนตำแหน่งในแกน Y (เหมือน y).	50px
// rotate	หมุนในแกน Z (2D rotation).	360 (องศา), -45deg
// rotateX	หมุนในแกน X (3D rotation).	45deg, -30deg
// rotateY	หมุนในแกน Y (3D rotation).	180deg, 90deg
// rotateZ	หมุนในแกน Z (เหมือน rotate).	15deg, 360deg
// scale	การขยาย/ย่อ ขนาดในทุกแกน.	1.5 (ขยาย 150%), 0.5
// scaleX	การขยาย/ย่อ ขนาดเฉพาะแกน X.	2 (ขยาย 200%)
// scaleY	การขยาย/ย่อ ขนาดเฉพาะแกน Y.	0.75 (ย่อเหลือ 75%)
// scaleZ	การขยาย/ย่อ ขนาดเฉพาะแกน Z.	1.2
// skewX	การบิดเบี้ยวในแกน X.	10deg, -20deg
// skewY	การบิดเบี้ยวในแกน Y.	5deg, 15deg
// perspective	ระยะมุมมองใน 3D (ระบุค่าใหญ่ขึ้นสำหรับมุมมองลึกขึ้น).	1000px, 500px
// opacity	ความโปร่งใส (0 = โปร่งใส, 1 = เต็ม).	0.5, 1, 0
// backgroundColor	เปลี่ยนสีพื้นหลัง.	"red", "#6575F6"
// color	เปลี่ยนสีข้อความ.	"black", "#FFFFFF"
// borderRadius	ปรับความโค้งของขอบ.	"50%", "10px"

import React, { useState } from "react";
import { easeInOut, motion } from "framer-motion";

import head from "../assets/images/Character/head.png";
import neck from "../assets/images/Character/neck.png";
import left_hand from "../assets/images/Character/left-hand.png";
import right_hand from "../assets/images/Character/right-hand.png";
import body from "../assets/images/Character/body.png";
import tail from "../assets/images/Character/tail.png";
import eye_normal from "../assets/images/Character/eye_normal.png";
import eye_sad from "../assets/images/Character/eye_sad.png";
import eye_happy from "../assets/images/Character/eye_happy.png";
import eye_sleep from "../assets/images/Character/eye_sleep.png";
import mouth_normal from "../assets/images/Character/mouth_normal.png";
import mouth_happy from "../assets/images/Character/mouth_happy.png";
import mouth_sad from "../assets/images/Character/mouth_sad.png";
import barrier from "../assets/images/Character/Ellipse 101.svg";
import { time } from "console";
import { duration } from "@mui/material";
import zIndex from "@mui/material/styles/zIndex";
import { left } from "@popperjs/core";
import {
  tailVariants,
  bodyVariants,
  leftHandVariants,
  rightHandVariants,
  headVariants,
  eyeVariants,
  mouthVariants,
  barrierVariants,
} from "./RaccoonVariants";
import Firefly from "./Firefly";

const RaccoonCharacter = () => {
  const [pose, setPose] = useState("idle");
  const randomInRange = (min: number, max: number) =>
    Math.random() * (max - min) + min;

  const [_eye, setEye] = useState(eye_normal);
  const [_mouth, setMouth] = useState(mouth_normal);
  const [_head, setHead] = useState(head);
  const [_neck, setNeck] = useState(neck);
  const [_body, setBody] = useState(body);
  const [_leftHand, setLeftHand] = useState(left_hand);
  const [_rightHand, setRightHand] = useState(right_hand);
  const [_tail, setTail] = useState(tail);

  const getVariant = (pose: string) => {
    console.log(pose);
    switch (pose) {
      default:
        setEye(eye_normal);
        setMouth(mouth_normal);
        return "idle";
      case "angry":
        setEye(eye_normal);
        setMouth(mouth_sad);
        return "angry";
      case "bye":
        setEye(eye_normal);
        setMouth(mouth_normal);
        return "bye";
      case "sad":
        setEye(eye_sad);
        setMouth(mouth_sad);
        return "sad";
      case "excited":
        setEye(eye_happy);
        setMouth(mouth_happy);
        return "wave";
    }
  };

  return (
    <motion.div
      style={{
        position: "relative",
        width: "300px",
        height: "300px",
        margin: "0 auto",
        fontFamily: "Caros Regular",
      }}
      onTap={() => {
        setPose("bye");
        setTimeout(() => setPose("idle"), 1000);
      }}
    >
      {/* หาง (Tail) */}
      <motion.img
        src={_tail}
        alt="Tail"
        style={{
          position: "absolute",
          bottom: "100px",
          left: "160px",
          width: "80px",
          zIndex: 1,
          transformOrigin: "left bottom",
        }}
        variants={tailVariants}
        animate={pose}
        onAnimationStart={() => getVariant(pose)}
      />

      {/* ตัว (Body) */}
      <motion.img
        src={_body}
        alt="Body"
        style={{
          position: "absolute",
          bottom: "75px",
          left: "80px",
          height: "110px",
          width: "125px",
          zIndex: 2,
        }}
        variants={bodyVariants}
        animate={pose}
      />

      {/* แขนซ้าย (Left Arm) */}
      <motion.img
        src={_leftHand}
        alt="Left Arm"
        style={{
          position: "absolute",
          top: "110px",
          left: "98px",
          width: "20%",
          zIndex: 3,
          transformOrigin: "left",
        }}
        variants={leftHandVariants}
        animate={pose}
      />

      {/* แขนขวา (Right Arm) */}
      <motion.img
        src={_rightHand}
        alt="Right Arm"
        style={{
          position: "absolute",
          top: "110px",
          left: "125px",
          width: "20%",
          zIndex: 3,
          transformOrigin: "right",
        }}
        variants={rightHandVariants}
        animate={pose}
      />

      {/* คอ (Neck) */}
      <motion.img
        src={_neck}
        alt="Neck"
        style={{
          position: "absolute",
          top: "120px",
          left: "90px",
          width: "35%",
          zIndex: 4,
          transformOrigin: "center",
        }}
        // variants={headVariants}
        animate={pose}
      />
      {/* หัว (Head) */}
      <motion.img
        src={_head}
        alt="Head"
        style={{
          position: "absolute",
          top: "40px",
          left: "70px",
          width: "145px",
          zIndex: 5,
          transformOrigin: "bottom",
        }}
        variants={headVariants}
        animate={pose}
      />
      {/* ตา (Eye) */}
      <motion.img
        src={_eye}
        alt="Eye"
        style={{
          position: "absolute",
          top: "40px",
          left: "71px",
          width: "140px",
          zIndex: 6,
          transformOrigin: "bottom",
        }}
        variants={eyeVariants}
        animate={pose}
      />
      {/* ปาก (Mouth) */}
      <motion.img
        src={_mouth}
        alt="Mouth"
        style={{
          position: "absolute",
          top: "43px",
          left: "73px",
          width: "140px",
          zIndex: 7,
          transformOrigin: "bottom",
        }}
        variants={mouthVariants}
        animate={pose}
      />

      <motion.img
        src={barrier}
        alt="barrier"
        style={{
          position: "absolute",
          top: "30px",
          left: "45px",
          width: "200px",
          zIndex: 8,
          transformOrigin: "center",
        }}
        variants={barrierVariants}
        animate={"idle"}
      />

      <motion.img
        src={barrier}
        alt="barrier"
        style={{
          position: "absolute",
          top: "30px",
          left: "45px",
          width: "200px",
          zIndex: 8,
          transformOrigin: "center",
        }}
        variants={barrierVariants}
        animate={"idle2"}
      />
      <motion.img
        src={barrier}
        alt="barrier"
        style={{
          position: "absolute",
          top: "30px",
          left: "45px",
          width: "200px",
          zIndex: 8,
          transformOrigin: "center",
        }}
        variants={barrierVariants}
        animate={"idle3"}
      />
      <Firefly />
      <Firefly />
      <Firefly />
      <Firefly />
      <Firefly />
      <Firefly />
      <Firefly />

      {/* ปุ่มควบคุม */}
      {/* <div style={{ textAlign: "center", marginTop: "20px" }}>
        <button onClick={() => setPose("idle")}>( Idle )</button>
        <button onClick={() => setPose("angry")}>( Angry )</button>
        <button onClick={() => setPose("bye")}>( Bye )</button>
        <button onClick={() => setPose("sad")}>( Sad )</button>
        <button onClick={() => setPose("excited")}>( Excited )</button>
      </div> */}
    </motion.div>
  );
};

export default RaccoonCharacter;
function handleHead() {
  throw new Error("Function not implemented.");
}
