import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { buyItem } from '../redux/actions';
import blackCat from "../assets/images/Landing/black-cat.png";
import closeButton from "../assets/images/btn-close-round.svg";
import turtle from "../assets/images/Landing/turtle.png";
import rlogoImage from "../assets/images/Landing/rlogo.png";
import { Rac } from '../assets/products/shopProducts';
import { useDispatch, useSelector } from 'react-redux';

interface MyModalProps {
  onClose: () => void;
  racItem: { img: string; rac?: number; price: number; lock: number; };
  notEnoughTon: () => void;
}

const ShopRacModal: React.FC<MyModalProps> = ({ onClose, racItem, notEnoughTon }) => {
  const [isClicked, setIsClicked] = useState(false);
  const [wear, setWear] = useState(false);
  const [item, setItem] = useState(null);
  const dispatch = useDispatch();
  const user = useSelector((state: any) => state.userData);
  useEffect(() => {
    console.log(racItem)
  }, [name]);

  const handleParagraphClick = () => {
    console.log(isClicked);
    setIsClicked(!isClicked);
  };

  const buy = () => {
    if(user.ton < racItem.price) {
      onClose();
      notEnoughTon();
    } else {
      dispatch({ type: 'BUY_RAC', payload: {rac: racItem.rac, ton: racItem.price} });
      onClose();
    }
  };

  if (!racItem) {
    return <div>Loading...</div>;
  }

  return (
    <div className='Modal-come bg-[#252D52] rounded-[30px] pb-[15px]'>
      <div className='absolute right-[20px] top-[20px]' onClick={onClose}>
        <img src={closeButton} alt="" />
      </div>
      <div className='center-img mt-[50px] mb-[10px]'>
        <img src={racItem.img} alt="tonIcon Img" className='m-auto w-[150px]'/>
      </div>
      <div className='text-area'>
        <div className='text-white text-[22px] justify-center flex'>{racItem.rac} <img src={rlogoImage} className='ml-[10px] w-[25px] h-[27px]' alt="" /></div>
        <div className='text-white text-[17px] text-center px-[30px]'>Instantly receive</div>
        <div className='text-white text-bold text-[18px] mt-[10px] text-center mb-[10px]'>{racItem.rac} Rac</div>
      </div>
      <button className='w-[80%] py-[10px] text-[20px] rounded-lg ml-[10%] bg-[#EA56D1] flex text-white justify-center' onClick={buy}>
        {racItem.price} TON
      </button>
    </div>
  );
};

export default ShopRacModal;
