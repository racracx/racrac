import { BottomNavigation, BottomNavigationAction } from "@mui/material";
import { useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import styled from "styled-components";
import { motion } from "framer-motion";
import { useSelector } from "react-redux";

// Components
import NavIcon from "./NavIcon";

// Menu Icons
import menuLanding from "../assets/images/menu-landing.svg";
import menuLandingActive from "../assets/images/menu-landing-active.svg";
import menuProfile from "../assets/images/menu-profile.svg";
import menuProfileActive from "../assets/images/menu-profile-active.svg";
import menuShop from "../assets/images/menu-shop.svg";
import menuShopActive from "../assets/images/menu-shop-active.svg";
import menuTask from "../assets/images/menu-task.svg";
import menuTaskActive from "../assets/images/menu-task-active.svg";
import noti from "../assets/images/noti.png";

// Constants
const ROUTES = {
  LANDING: "/landing",
  TASK: "/task",
  SHOP: "/shop",
  PROFILE: "/profile",
} as const;

const ROUTES_ARRAY = Object.values(ROUTES);

const PATH_TO_INDEX: Record<string, number> = {
  [ROUTES.LANDING]: 0,
  [ROUTES.TASK]: 1,
  [ROUTES.SHOP]: 2,
  [ROUTES.PROFILE]: 3,
} as const;

// Navigation Items
const NAV_ITEMS = (hasNotify: boolean) => [
  { icon: menuLanding, activeIcon: menuLandingActive, hasNotification: false },
  { icon: menuTask, activeIcon: menuTaskActive, hasNotification: !hasNotify },
  { icon: menuShop, activeIcon: menuShopActive, hasNotification: false },
  { icon: menuProfile, activeIcon: menuProfileActive, hasNotification: false },
] as const;

// Styled Components
const StyledBottomNavigation = styled(BottomNavigation)`
  width: 100%;
  position: fixed;
  padding: 30px 20px 50px 20px;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 1000;
`;

interface BottomNavProps {}

const BottomNav: React.FC<BottomNavProps> = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [value, setValue] = useState<number>(1);

  const user = useSelector((state: any) => state.userData);

  useEffect(() => {
    setValue(PATH_TO_INDEX[pathname] ?? -1);
  }, [pathname, user]);

  const handleChange = (
    _: React.ChangeEvent<unknown>,
    newValue: number
  ): void => {
    setValue(newValue);
    navigate(ROUTES_ARRAY[newValue]);
  };

  return (
    <StyledBottomNavigation
      sx={{
        background: "#0D0D0D",
        fontFamily: "Caros Regular"
      }}
      showLabels={false}
      value={value}
      onChange={handleChange}
    >
      {NAV_ITEMS(user.getDailyReward).map((item, index) => (
        <BottomNavigationAction
          key={`nav-item-${index}`}
          icon={
            <motion.div
              style={{ position: "relative" }} // สำหรับวางตำแหน่งจุด
              whileHover={{
                scale: 1.2,
                rotate: 5,
              }}
              whileTap={{
                scale: 0.75,
              }}
              animate={value === index ? { y: [0, -5, 0] } : {}}
              transition={{
                type: "spring",
                stiffness: 300,
                damping: 20,
                duration: 0.5,
              }}
            >
              <NavIcon
                src={item.icon}
                activeSrc={item.activeIcon}
                isActive={value === index}
              />
              {item.hasNotification && (
                <img
                  src={noti}
                  alt="notification"
                  style={{
                    position: "absolute",
                    top: "0px",
                    right: "-15px",
                    width: "13px",
                    height: "13px",
                  }}
                />
              )} {/* จุดแจ้งเตือน */}
            </motion.div>
          }
        />
      ))}
    </StyledBottomNavigation>
  );
};

export default BottomNav;
