import React from "react";
import { motion } from "framer-motion";

const CustomButton = ({
  text = "Click Me", // ข้อความบนปุ่ม
  icon = null, // ไอคอนบนปุ่ม
  style = {}, // สไตล์เพิ่มเติม
  hoverEffect = {}, // เอฟเฟกต์เมื่อ Hover
  tapEffect = {}, // เอฟเฟกต์เมื่อกด
  animation = {}, // อนิเมชั่นพิเศษ
  disabled = false, // ปิดการใช้งานปุ่ม
  ...rest // รับ Props อื่นๆ เหมือน button
}) => {
  return (
    <motion.button
      className="custom-button px-[15px] rounded-lg py-[10px] text-sm mt-[10px]"
      style={{
        background: disabled ? "#ccc" : "#EA56D1", // พื้นหลังปุ่ม
        color: disabled ? "#666" : "#fff", // สีตัวอักษร
        cursor: disabled ? "not-allowed" : "pointer", // เปลี่ยน cursor ถ้า disabled
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "10px", // ระยะห่างระหว่างไอคอนและข้อความ
        ...style, // รวมสไตล์เพิ่มเติม
      }}
      whileHover={!disabled ? hoverEffect : {}} // ไม่ทำงานเมื่อ disabled
      whileTap={!disabled ? tapEffect : {}} // ไม่ทำงานเมื่อ disabled
      animate={animation}
      disabled={disabled}
      {...rest} // ส่งต่อ Props อื่นๆ ทั้งหมด
    >
      {icon && <span>{icon}</span>} {/* แสดงไอคอนถ้ามี */}
      {text}
    </motion.button>
  );
};

export default CustomButton;
