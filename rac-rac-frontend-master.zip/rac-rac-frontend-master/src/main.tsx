import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { Provider } from 'react-redux';
import store from './redux/store'
import { BrowserRouter as Router } from 'react-router-dom';
import { retrieveLaunchParams } from '@telegram-apps/sdk';
import { init } from './init'
// Mock the environment in case, we are outside Telegram.
import './mockEnv.ts'

const manifestUrl =
  "https://rr.racrac.co/ton/ton-connect-manifest.json";

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false } },
});

// Configure all application dependencies.
init(retrieveLaunchParams().startParam === 'debug' || import.meta.env.DEV)

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <TonConnectUIProvider manifestUrl={manifestUrl}>
    <QueryClientProvider client={queryClient}>
      <Provider store={store}>
        <Router>
          <App />
        </Router>
      </Provider>
    </QueryClientProvider>
  </TonConnectUIProvider>
);
