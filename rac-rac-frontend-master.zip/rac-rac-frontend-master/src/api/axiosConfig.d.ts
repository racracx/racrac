   // src/api/axiosConfig.d.ts
   import { AxiosInstance } from 'axios';

   declare const apiClient: AxiosInstance;
   export default apiClient;