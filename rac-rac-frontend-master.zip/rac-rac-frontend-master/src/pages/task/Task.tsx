import apiClient from '../../api/axiosConfig';
import React, { useState, useEffect } from "react";
import {
  Button,
  Modal,
  ModalBody,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
} from "reactstrap";
import { Link, useNavigate } from "react-router-dom";
import toast, { Toaster } from 'react-hot-toast';
import { useTonConnectUI } from "@tonconnect/ui-react";
import { useTonConnect } from "../../hooks/useTonConnect";
import { retrieveLaunchParams, openTelegramLink } from '@telegram-apps/sdk';

import "./Task.css";
import "bootstrap/dist/css/bootstrap.min.css";

import racraclogo from "../../assets/images/Landing/RACRAC LOGO.png";
import rlogoImage from "../../assets/images/coin-racrac.svg";
import rlogoInactiveImage from "../../assets/images/coin-racrac-inactive.png";
import lockImage from "../../assets/images/Landing/lock-item.png";
import lock from "../../assets/images/Landing/lock.png";
import twitterImage from "../../assets/images/Landing/twitter.png";
import tonIconImage from "../../assets/images/Landing/ton-icon.png";
import instagramImage from "../../assets/images/Landing/instagram.png";
import tasksBanner from "../../assets/images/Landing/tasks-banner.png";
import telegramImage from "../../assets/images/Landing/telegram-icon.png";
import banner1 from "../../assets/images/Landing/Task Page Banner.png";
import banner2 from "../../assets/images/Landing/Task Page Banner (1).png";
import banner3 from "../../assets/images/Landing/Task Page Banner (2).png";
import banner1SVG from "../../assets/images/Landing/Task Page Banner.svg";
import banner2SVG from "../../assets/images/Landing/Task Page Banner (1).svg";
import banner3SVG from "../../assets/images/Landing/Task Page Banner (2).svg";
import linkbutton from "../../assets/images/Landing/link-button.png";
import closebutton from "../../assets/images/btn-close-round.svg";
import Become from "../../components/Become";
import { connect } from "react-redux";
import { useDispatch, useSelector } from "react-redux";
import { motion } from "framer-motion";
import { Award } from "../../assets/products/shopProducts";
import ClaimButton from "../../components/ClaimButton";
import MotionWrapper from "../../components/MotionWrapper";

interface ClaimItem {
  claimTitle: string;
  socialImage: string;
  isButton: boolean;
  isLock: boolean;
}

interface LaunchParams {
  initDataRaw: string;
}

const claimList: ClaimItem[] = [
  {
    claimTitle: "Join our Telegram Community",
    socialImage: telegramImage,
    isButton: true,
    isLock: false,
  },
  {
    claimTitle: "Follow our X (formerly Twitter)",
    socialImage: twitterImage,
    isButton: false,
    isLock: true,
  },
  {
    claimTitle: "Follow our Instagram Account",
    socialImage: instagramImage,
    isButton: false,
    isLock: true,
  },
];

interface TaskProps {
  updateModalContent: (content: React.ReactNode) => void;
  toggle: () => void;
  setModalType: (type: string) => void;
}

const Task: React.FC<TaskProps> = ({
  updateModalContent,
  toggle,
  setModalType,
}) => {
  const navigate = useNavigate();
  const { connected, wallet } = useTonConnect();
  const [tonConnectUI, setOptions] = useTonConnectUI();
  const [activeTab, setActiveTab] = useState<string>("2");
  const [isClaimAnimation, setIsClaimAnimation] = useState<boolean>(false);
  const [isClaimAnimation1, setIsClaimAnimation1] = useState<boolean>(false);
  const [isClaimAnimation2, setIsClaimAnimation2] = useState<boolean>(false);
  const user = useSelector((state: any) => state.userData);
  const dispatch = useDispatch();

  const { initDataRaw, initData } = retrieveLaunchParams();
  const userId = initData?.user?.id
  const startParam = initData?.startParam

  // const [referrals, setReferrals] = useState<string[]>([])
  // const [referrer, setReferrer] = useState<string | null>(null)
  const INVITE_URL = "https://t.me/rr_racrac_bot"

  useEffect(() => {
    // const checkReferral = async () => {
    //   if (startParam && userId) {
    //     try {
    //       const response = await fetch('/api/referrals', {
    //         method: 'POST',
    //         headers: { 'Content-Type': 'application/json' },
    //         body: JSON.stringify({ userId, referrerId: startParam }),
    //       });
    //       if (!response.ok) throw new Error('Failed to save referral');
    //     } catch (error) {
    //       console.error('Error saving referral:', error);
    //     }
    //   }
    // }

    // const fetchReferrals = async () => {
    //   if (userId) {
    //     try {
    //       const response = await fetch(`/api/referrals?userId=${userId}`);
    //       if (!response.ok) throw new Error('Failed to fetch referrals');
    //       const data = await response.json();
    //       setReferrals(data.referrals);
    //       setReferrer(data.referrer);
    //     } catch (error) {
    //       console.error('Error fetching referrals:', error);
    //     }
    //   }
    // }

    // checkReferral();
    // fetchReferrals();
  }, [userId, startParam])

  const handleInviteFriend = () => {
    const inviteLink = `${INVITE_URL}?startapp=${userId}`
    const shareText = `Join me on this awesome Telegram mini app!`
    const fullUrl = `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(shareText)}`
    openTelegramLink(fullUrl)
    setIsClaimAnimation2(true);
  }

  const handleCopyLink = () => {
    const inviteLink = `${INVITE_URL}?startapp=${userId}`
    navigator.clipboard.writeText(inviteLink)
    toast('Invite link copied to clipboard!');
  }

  const toggleTab = (tab: string) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const simulateData = async (id: string, racBalance: number) => {
    try {
      await apiClient.post("/api/users/login",
        { id: id, racBalance: racBalance },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${initDataRaw}`,
          }
        }
      );
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  const handleAnimationClaim = () => {
  if (!user.getDailyReward) {
    const currentAward = Award[user.loginStreakCount - 1];
    if (currentAward) {
      simulateData(user.id, currentAward.award);
      dispatch({ type: "SET_DAILYREWARD", payload: 1 });
      dispatch({ type: "SET_CONTINUELOGIN", payload: user.loginStreakCount + 1 });
      dispatch({
        type: "SET_RAC",
        payload: user.racBalance + currentAward.award,
      });
    }
  } else {
    return;
  }
};

  const handleAnimationClaim1 = () => {
    setIsClaimAnimation1(true);
  };

  const handleAnimationClaim2 = () => {
    setIsClaimAnimation2(true);
  };

  return (
    <div className="landing-screen task-screen" style={{ fontFamily: "Caros Regular" }}>
      <Toaster position="bottom-center"/>
      <div className="game-fit-screen">
        <div className="tapbox">
          <Link to="/" className="absolute right-[35px] mt-[10px]">
            <img src={closebutton} alt="" />
          </Link>
          <div className="banner">
            {activeTab === "1" && (
              <img src={banner1SVG} className="rounded-t-lg w-full" />
            )}
            {activeTab === "2" && (
              <img src={banner2SVG} className="rounded-t-lg w-full" />
            )}
            {activeTab === "3" && (
              <img src={banner3SVG} className="rounded-t-lg w-full" />
            )}
          </div>
          <Nav
            tabs
            style={{
              backgroundColor: "#1C1C1E", // เปลี่ยนสีพื้นหลังหลัก
              position: "relative",
              fontFamily: "Caros Regular"
            }}
          >
            {/* เส้นแสดงตำแหน่ง Tab ที่เลือก */}
            <div
              style={{
                position: "absolute",
                top: 5, // เส้นอยู่ใต้ข้อความ
                left: `calc(${((parseInt(activeTab) - 1) * 100) / 3}% + 16%)`, // เลื่อนเส้นให้ตรงกลาง Tab
                height: "3px", // ความสูงของเส้น
                width: "15%", // ลดความกว้างเส้น
                backgroundColor: "#6575F6", // สีเส้น
                transform: "translateX(-50%)", // จัดให้อยู่กึ่งกลางของ Tab
                transition: "left 0.3s ease, width 0.3s ease", // ทำให้นุ่มนวลเมื่อเปลี่ยน Tab
              }}
            />
            <div
              style={{
                position: "absolute",
                top: 5, // เส้นอยู่ใต้ข้อความ
                height: "3px", // ความสูงของเส้น
                width: "90%", // ความกว้างของเส้น
                backgroundColor: "#6575F640", // สีเด่นชัด
                transform: "translateX(0%)", // จัดให้อยู่กึ่งกลางของ Tab
              }}
            />

            {/* Tab Login */}
            <NavItem style={{ flex: 1, textAlign: "center" }}>
              <MotionWrapper>
                <NavLink
                  className={activeTab === "1" ? "active" : ""}
                  onClick={() => toggleTab("1")}
                  style={{
                    color:
                      activeTab === "1"
                        ? "#6575F6"
                        : "rgba(101, 117, 246, 0.4)", // เปลี่ยนสีตามสถานะ
                    fontWeight: activeTab === "1" ? "bold" : "normal", // เพิ่มตัวหนา
                    transition: "color 0.3s ease, font-weight 0.3s ease", // ทำให้การเปลี่ยนสีและความหนานุ่มนวล
                    fontFamily: "Caros Regular",
                  }}
                >
                  Login
                </NavLink>
              </MotionWrapper>
            </NavItem>

            {/* Tab Missions */}
            <NavItem style={{ flex: 1, textAlign: "center" }}>
              <MotionWrapper>
                <NavLink
                  className={activeTab === "2" ? "active" : ""}
                  onClick={() => toggleTab("2")}
                  style={{
                    color:
                      activeTab === "2"
                        ? "#6575F6"
                        : "rgba(101, 117, 246, 0.4)",
                    fontWeight: activeTab === "2" ? "bold" : "normal",
                    transition: "color 0.3s ease, font-weight 0.3s ease",
                    fontFamily: "Caros Regular",
                  }}
                >
                  Missions
                </NavLink>
              </MotionWrapper>
            </NavItem>

            {/* Tab Invite */}
            <NavItem style={{ flex: 1, textAlign: "center" }}>
              <MotionWrapper>
                <NavLink
                  className={activeTab === "3" ? "active" : ""}
                  onClick={() => toggleTab("3")}
                  style={{
                    color:
                      activeTab === "3"
                        ? "#6575F6"
                        : "rgba(101, 117, 246, 0.4)",
                    fontWeight: activeTab === "3" ? "bold" : "normal",
                    transition: "color 0.3s ease, font-weight 0.3s ease",
                    fontFamily: "Caros Regular",
                  }}
                >
                  Invite
                </NavLink>
              </MotionWrapper>
            </NavItem>
          </Nav>

          <TabContent
            activeTab={activeTab}
            style={{
              backgroundColor: "#1C1C1E", // เปลี่ยนสีพื้นหลังหลัก
              fontFamily: "Caros Regular"
            }}
          >
            <TabPane tabId="1" className="award-panel">
              <div className="parent-award flex justify-between">
                {Award.map((item, index) => (
                  <div
                    key={index}
                    className="p-[10px] rounded-[10px] bg-[#0D0D0D] "
                  >
                    {item && (
                      <>
                        <div
                          className="text-[#6366f1] text-[11px] text-center mb-[5px] font-bold"
                          style={{ fontFamily: "Caros Regular" }}
                        >
                          DAY {item.daily}
                        </div>
                        <img
                          src={
                            index < user.loginStreakCount
                              ? rlogoImage
                              : rlogoInactiveImage
                          }
                          alt=""
                          className="m-auto w-[30px] h-[30px]"
                        />
                        {index < user.loginStreakCount - 1 && (
                          <motion.button
                            className="px-[15px] rounded-lg py-[3px] text-sm mt-[10px]"
                            style={{
                              color: "#3E4867",
                              fontFamily: "Caros Regular",
                            }}
                            animate={{
                              scale: [1, 1.05, 1], // ขยายและหดกลับเป็น loop
                            }}
                            transition={{
                              duration: 1.5, // ระยะเวลาอนิเมชั่น
                              repeat: Infinity, // วนลูปไม่มีที่สิ้นสุด
                              repeatType: "reverse", // ย้อนกลับระหว่างการวนลูป
                            }}
                            whileHover={{
                              scale: 1.2,
                              backgroundColor: "#3E4867",
                              color: "#FFFFFF",
                            }}
                          >
                            Claimed
                          </motion.button>
                        )}
                        {index === user.loginStreakCount - 1 && (
                          <button
                            className="button px-[15px] rounded-lg py-[3px] text-sm mt-[10px]"
                            style={{
                              background: user.getDailyReward
                                ? "#1A2035"
                                : "#EA56D1",
                              color: user.getDailyReward ? "#3E4867" : "#fff",
                              fontFamily: "Caros Regular",
                            }}
                            onClick={handleAnimationClaim}
                          >
                            Claimed
                          </button>
                        )}
                        {index >= user.loginStreakCount && (
                          <div
                            className="button px-[15px] rounded-lg py-[3px] text-sm mt-[10px] text-center font-bold"
                            style={{
                              color: "#6366f1",fontFamily: "Caros Regular"
                            }}
                          >
                            {index === 6 ? "bonus" : 30 + 10 * (index + 1)}
                          </div>
                          // <img
                          //   src={lock}
                          //   className="px-[10px] m-auto pt-[16px]"
                          // />
                        )}
                      </>
                    )}
                  </div>
                ))}
              </div>
            </TabPane>
            <TabPane tabId="2" className="px-[20px]">
              <div className="justify-between flex bg-[#0D0D0D] p-[15px] rounded-lg mb-[10px]">
                <div className="w-[70%]">
                    <p className="text-white text-[13px]" style={{ fontFamily: "Caros Regular" }}>
                    Interact with RACRAC (2x)
                    </p>
                  <p className="text-[#6366f1] text-[11px]" style={{ fontFamily: "Caros Regular" }}>+15 Rac</p>
                </div>
                <img
                  src={lockImage}
                  alt=""
                  className="m-auto w-[20px] h-[25px] filter grayscale"
                />
                {/* <div className="w-[25%]">
                  <ClaimButton
                    isClaimAnimation={isClaimAnimation1}
                    onClick={handleAnimationClaim1}
                    text="Claim"
                    style={{
                      border: "2px solid #FF69B4", // เพิ่มเส้นขอบ
                      borderRadius: "12px", // ทำให้ขอบมนเพิ่ม
                      padding: "5px 10px", // ปรับ Padding
                    }}
                  />
                </div> */}
              </div>
              <div className="justify-around flex bg-[#0D0D0D] p-[15px] rounded-lg mb-[10px]">
                <div className="w-[200%]">
                    <p className="text-white text-[13px]" style={{ fontFamily: "Caros Regular" }}>Equip an item</p>
                  <p className="text-[#6366f1] text-[11px]" style={{ fontFamily: "Caros Regular" }}>+10 Rac</p>
                </div>
                <img
                  src={lockImage}
                  alt=""
                  className="m-auto w-[20px] h-[25px] filter grayscale"
                />
                <div className="w-[30%]"></div>
              </div>
              <div className="justify-around flex bg-[#0D0D0D] p-[15px] rounded-lg mb-[10px]">
                <div className="w-[200%]">
                  <p className="text-white text-[13px]" style={{ fontFamily: "Caros Regular" }}>
                    Feed RACRAC (1x)
                  </p>
                  <p className="text-[#6366f1] text-[11px]" style={{ fontFamily: "Caros Regular" }}>+10 Rac</p>
                </div>
                <img
                  src={lockImage}
                  alt=""
                  className="m-auto w-[20px] h-[25px] filter grayscale"
                />
                <div className="w-[30%]"></div>
              </div>
              <div className="justify-between flex bg-[#0D0D0D] p-[15px] rounded-lg mb-[10px]">
                <div className="w-[200%]">
                  <p className="text-white text-[13px]" style={{ fontFamily: "Caros Regular" }}>
                    Complete 20 daily missions
                  </p>
                  <p className="text-[#6366f1] text-[11px]" style={{ fontFamily: "Caros Regular" }}>+100 Rac</p>
                </div>
                <img
                  src={lockImage}
                  alt=""
                  className="m-auto w-[20px] h-[25px] filter grayscale"
                />
                <div className="w-[30%]"></div>
              </div>
            </TabPane>
            <TabPane tabId="3" className="px-[20px]">
              <div className="justify-between flex bg-[#0D0D0D] p-[15px] rounded-lg mb-[10px]">
                <div className="w-[60%]">
                  <p className="text-white text-[13px]" style={{ fontFamily: "Caros Regular" }}>Invite a friend</p>
                  <p className="text-[#6366f1] text-[11px]" style={{ fontFamily: "Caros Regular" }}>+50 Rac</p>
                </div>
                <div className="w-[30%]">
                  <ClaimButton
                    isClaimAnimation={isClaimAnimation2}
                    onClick={handleInviteFriend}
                    text="Invite"
                    style={{
                      border: "2px solid #6366f1", // เพิ่มเส้นขอบ
                      borderRadius: "7px", // ทำให้ขอบมนเพิ่ม
                    }}
                  />
                </div>
              </div>
              <div className="justify-between flex bg-[#0D0D0D] p-[15px] rounded-lg mb-[10px]">
                <div className="w-[80%]">
                  <p className="text-white text-[13px]" style={{ fontFamily: "Caros Regular" }}>Invite 5 friends</p>
                  <p className="text-[#6366f1] text-[11px]" style={{ fontFamily: "Caros Regular" }}>+150 Rac</p>
                </div>
                <div className="w-[30%]"></div>
                <ClaimButton
                  isClaimAnimation={isClaimAnimation2}
                  onClick={handleAnimationClaim2}
                  text="Incomplete"
                  style={{
                    border: "2px solid #6366f1", // เพิ่มเส้นขอบ
                    borderRadius: "7px", // ทำให้ขอบมนเพิ่ม
                  }}
                />
              </div>
              <motion.button
                className="bg-[#6366f1] w-full text-white py-[10px] rounded-lg mt-[40px]"
                // onClick={() => updateModalContent(<Become onClose={toggle} />)}
                onClick={handleInviteFriend}
                whileHover={{
                  scale: 1.05, // ขยายเล็กน้อยเมื่อ Hover
                  boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)", // เพิ่มเงา
                }}
                whileTap={{
                  scale: 0.95, // ลดขนาดเล็กน้อยเมื่อกด
                }}
                transition={{
                  type: "spring",
                  stiffness: 300,
                  damping: 20,
                }}
                style={{ fontFamily: "Caros Regular" }}
              >
                Invite friends
              </motion.button>
              <div className="justify-between flex mt-[15px] w-full">
                <motion.button
                  onClick={handleCopyLink}
                  className="bg-[#0D0D0D] text-[#6366f1] py-[10px] rounded-lg w-full"
                  whileHover={{
                    scale: 1.05,
                    backgroundColor: "#007ACC", // เปลี่ยนสีพื้นหลังเมื่อ Hover
                  }}
                  whileTap={{
                    scale: 0.95,
                  }}
                  transition={{
                    type: "spring",
                    stiffness: 300,
                    damping: 20,
                  }}
                  style={{ fontFamily: "Caros Regular" }}
                >
                  Copy invitation link
                </motion.button>
              </div>
            </TabPane>
          </TabContent>
          {/* {!connected && (
            <button
              onClick={() => tonConnectUI.connectWallet()}
              className="bg-[#6575F6] w-full py-[14px] px-[20px] rounded-b-lg text-start text-white"
            >
              Connect Wallet
            </button>
          )} */}
        </div>
      </div>
    </div>
  );
};

export default Task;
