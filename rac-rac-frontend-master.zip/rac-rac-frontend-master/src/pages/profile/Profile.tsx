import React from "react";
import { useSelector } from 'react-redux';
import { Link } from "react-router-dom";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import { useTonConnectUI } from "@tonconnect/ui-react";
import { useTonConnect } from "../../hooks/useTonConnect";
import WithDraw from "../../components/WithDraw";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-tabs/style/react-tabs.css";
import "./Profile.css";

import userImage from "../../assets/images/Landing/user-img.png";
import rlogoImage from "../../assets/images/coin-racrac.svg";
import tonIconImage from "../../assets/images/coin-ton.svg";
import closeImage from "../../assets/images/btn-close.svg";
import racrac from "../../assets/images/text-racrac.svg";
import raccome from "../../assets/images/rac-coins-stats.svg";
import imgWallet from "../../assets/images/wallet.svg";
import myrac from "../../assets/images/text-my-rac.svg";
import MotionWrapper from "../../components/MotionWrapper";

interface ProfileProps {
  updateModalContent: (content: React.ReactNode) => void;
  toggle: () => void;
  setModalType: (type: string) => void;
}

const Profile: React.FC<ProfileProps> = ({
  updateModalContent,
  toggle,
  setModalType,
}) => {
  const { connected, wallet } = useTonConnect();
  const [tonConnectUI, setOptions] = useTonConnectUI();
  const user = useSelector((state: any) => state.userData);

  return (
    <div className="landing-screen profile-screen">
      <div className="game-fit-screen">
        <div className="tapbox">
          <div className="title-area">
            <div className="m-auto pt-[7px] flex w-full">
              <h1 className="w-full">
                <img src={imgWallet} alt="" className="m-auto" />
              </h1>
              <Link to="/" className="absolute right-[35px]">
                <img src={closeImage} alt={`Close Image`} />
              </Link>
            </div>
            <div className="user-area">
              <div className="img-box rounded-full overflow-hidden">
                <img
                  src={user?.photo_url || userImage}
                  alt={`User Image`}
                  className="w-full h-full object-cover"
                />
              </div>
              {user ? (
                <h3>
                  {user?.first_name +
                    " " +
                    user?.last_name}
                </h3>
              ) : (
                <h3>RAC RAC</h3>
              )}
            </div>
          </div>

          <div className="tabs-box rounded-lg">
            <Tabs>
              <TabList>
                <Tab>Profile</Tab>
                <Tab>Swap</Tab>
              </TabList>

              <TabPanel>
                <div className="panel-area ">
                  <div className="title-area">
                    <h3>
                      <img src={myrac} alt="" />
                    </h3>
                    <button className="change-btn">Remove</button>
                  </div>
                  <div className="form-area">
                    <div className="group-form">
                      <input type="text" placeholder="RACRAC" />
                    </div>
                    <div className="group-form">
                      <textarea placeholder="Bio"></textarea>
                    </div>
                  </div>
                </div>
              </TabPanel>
              <TabPanel>
                <div className="panel-area">
                  <img src={raccome} alt="" className="mb-[30px] w-full" />
                  <div className="title-area">
                    <h3>
                      <span className="icon">
                        <img src={rlogoImage} alt="tonIcon Img" />
                      </span>
                      <img src={racrac} alt="" />
                    </h3>
                    <button className="change-btn">Change</button>
                  </div>
                  <div className="form-area">
                    <div className="group-form">
                      <input
                        type="text"
                        placeholder="Address"
                        defaultValue={connected ? wallet || "" : ""}
                      />
                    </div>
                  </div>

                  <div className="justify-between w-full flex mt-[10px]">
                    <MotionWrapper
                      className="w-[48%] flex justify-between bg-white p-[20px] rounded-lg"
                      onClick={() =>
                        updateModalContent(<WithDraw onClose={toggle} />)
                      }
                    >
                      <div className="w-[30%]">
                        <img src={tonIconImage} alt="" />
                      </div>
                      <div className="w-[40%] text-[#0098EA] text-[18px] pl-[10px]">
                        5
                      </div>
                      <div className="w-[30%] text-[#0098EA] text-[12px] mt-[3px]">
                        +Fee
                      </div>
                    </MotionWrapper>
                    <MotionWrapper className="w-[48%] flex justify-between bg-white p-[20px] rounded-lg">
                      <div className="w-[30%]">
                        <img src={tonIconImage} alt="" />
                      </div>
                      <div className="w-[40%] text-[#0098EA] text-[18px] pl-[10px]">
                        10
                      </div>
                      <div className="w-[30%] text-[#0098EA] text-[12px] mt-[3px]">
                        +Fee
                      </div>
                    </MotionWrapper>
                  </div>
                  <div className="justify-between w-full flex mt-[10px]">
                    <MotionWrapper className="w-[48%] flex justify-between bg-white p-[20px] rounded-lg">
                      <div className="w-[30%]">
                        <img src={tonIconImage} alt="" />
                      </div>
                      <div className="w-[40%] text-[#0098EA] text-[18px] pl-[10px]">
                        20
                      </div>
                      <div className="w-[30%] text-[#0098EA] text-[12px] mt-[3px]">
                        +Fee
                      </div>
                    </MotionWrapper>
                    <MotionWrapper className="w-[48%] flex justify-between bg-white p-[20px] rounded-lg">
                      <div className="w-[30%]">
                        <img src={tonIconImage} alt="" />
                      </div>
                      <div className="w-[40%] text-[#0098EA] text-[18px] pl-[10px]">
                        30
                      </div>
                      <div className="w-[30%] text-[#0098EA] text-[12px] mt-[3px]">
                        +Fee
                      </div>
                    </MotionWrapper>
                  </div>
                </div>
              </TabPanel>
            </Tabs>
            {!connected && (
              <button
                onClick={() => tonConnectUI.connectWallet()}
                className="bg-white text-[#6575F6] w-full py-[14px] px-[20px] rounded-b-lg text-start absolute z-1 bottom-[0]"
              >
                Connect Wallet
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
