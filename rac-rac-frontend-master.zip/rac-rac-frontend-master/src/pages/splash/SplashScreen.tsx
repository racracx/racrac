import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import characterImage from '../../assets/images/splash-screen.svg';

// Styled components
const SplashScreenContainer = styled.div`
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
`;

const CenterScreen = styled.div`
    position: relative;
    width: 100%;
    max-width: 500px;
    background-color: #6575F6;
    margin: 0 26px;
    border-radius: 19px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

const ScreenInner = styled.div`
    position: relative;
    padding: 21px 36px;
    min-height: 350px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
`;

const CharacterArea = styled.div`
    position: relative;
    text-align: center;
    margin: 33px 0 30px;
    
    img {
        margin: 0 auto;
        max-width: 100%;
        height: auto;
    }
`;

const TextBox = styled.div`
    position: relative;
    text-align: center;

    h2 {
        font-size: clamp(16px, 5vw, 20px);
        color: #fff;
        font-family: 'Caros Regular', sans-serif;
        margin-bottom: 82px;

        span {
            font-family: 'Brigends Expanded', sans-serif;
        }
    }
`;

const GetStartedLink = styled(Link)`
    background-color: #fff;
    padding: 16px 25px;
    width: 100%;
    display: block;
    border-radius: 9px;
    font-size: 18px;
    color: #6575F6;
    font-family: 'Caros Medium', sans-serif;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s ease-in-out;

    &:hover, 
    &:focus {
        background-color: #FA5C5C;
        color: #fff;
        transform: translateY(-2px);
    }

    &:active {
        transform: translateY(0);
    }
`;

const TextSpan = styled.div`
    position: relative;
    text-align: center;
    font-size: 12px;
    color: rgba(255, 255, 255, 0.8);
    font-family: 'Caros Regular', sans-serif;
    margin-top: 14px;
`;

interface SplashScreenProps {}

const SplashScreen: React.FC<SplashScreenProps> = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const REDIRECT_DELAY = 2000;
        const timer = setTimeout(() => {
            navigate('/');
        }, REDIRECT_DELAY);

        return () => clearTimeout(timer);
    }, [navigate]);

    return (
        <SplashScreenContainer>
            <CenterScreen>
                <ScreenInner>
                    <CharacterArea>
                        <img 
                            src={characterImage} 
                            alt="Welcome Character"
                            loading="eager"
                        />
                    </CharacterArea>
                    <TextBox>
                        <GetStartedLink to="/">
                            Let's Get Started!
                        </GetStartedLink>
                    </TextBox>
                    <TextSpan>
                        By clicking 'Start,' you agree to our Terms and Conditions.
                    </TextSpan>
                </ScreenInner>
            </CenterScreen>
        </SplashScreenContainer>
    );
};

export default SplashScreen;
