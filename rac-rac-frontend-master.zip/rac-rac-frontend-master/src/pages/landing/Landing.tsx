import apiClient from '../../api/axiosConfig';
import { Button } from "reactstrap";
import { Link, useNavigate } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { useTonConnect } from "../../hooks/useTonConnect";
import { retrieveLaunchParams } from "@telegram-apps/sdk";

import { SHOP_PRODUCTS } from "../../assets/products/shopProducts";
import { Item } from "../../assets/products/shopProducts";
import { Board } from "../../assets/products/shopProducts";

import "./Landing.css";
import "bootstrap/dist/css/bootstrap.min.css";
import ShopItemModal from "../../components/ShopItemModal";
import FoodCome from "../../components/FoodCome";

import rlogoImage from "../../assets/images/Landing/rlogo.png";
import charctor1Image from "../../assets/images/Landing/tap-1.png";
import charctor2Image from "../../assets/images/Landing/tap-2.png";
import tonIconImage from "../../assets/images/Landing/ton-icon.png";
import racraclogo from "../../assets/images/Landing/RACRAC LOGO.png";
import myRac from "../../assets/images/Landing/MY RAC.png";
import groupBg from "../../assets/images/Landing/group-bg.png";
import food from "../../assets/images/Landing/Feed _ Coming Soon Pop-up.png";
import itemTitle from "../../assets/images/Landing/ITEMS.png";
import board from "../../assets/images/Landing/Group 235777.png";
import lboard from "../../assets/images/Landing/leaderboard.png";
import closebutton from "../../assets/images/btn-close.svg";
import trustImg from "../../assets/images/Landing/trust.png";
import cautiousImg from "../../assets/images/Landing/state/Vector (1).png";
import friendlyImg from "../../assets/images/Landing/state/Vector (2).png";
import loyalImg from "../../assets/images/Landing/state/Vector (3).png";
import devotedImg from "../../assets/images/Landing/state/Vector (4).png";
import { connect } from "react-redux";
import { useDispatch, useSelector } from "react-redux";

import happinessImg0 from "../../assets/images/Landing/Happiness.png";
import happinessImg1 from "../../assets/images/Landing/state/Group 235620.png";
import happinessImg2 from "../../assets/images/Landing/state/Group 235620 (1).png";
import happinessImg3 from "../../assets/images/Landing/state/Group 235620 (1).png";
import happinessImg4 from "../../assets/images/Landing/state/Group 235620 (1).png";

import hatImg1 from "../../assets/images/Landing/item/Layer_1 (1).png";
import hatImg2 from "../../assets/images/Landing/item/Layer_1 (3).png";
import hatImg3 from "../../assets/images/Landing/item/Layer_1 (7).png";
import hatImg4 from "../../assets/images/Landing/item/Layer_1 (8).png";

import modelImg1 from "../../assets/images/Landing/littlehero.png";
import modelImg2 from "../../assets/images/Landing/girlshirt.png";
import modelImg3 from "../../assets/images/Landing/racracshirt.png";

import neckImg from "../../assets/images/Landing/item/Group.png";
import { motion } from "framer-motion";
import RaccoonCharacter from "../../components/RaccoonCharacter";
import bg_rac from "../../assets/images/Character/bg-rac.svg";
import barrier from "../../assets/images/Character/Ellipse 101.svg";
import rib from "../../assets/images/Character/Ripple.png";
import rac from "../../assets/images/Character/racrac-bg.png";

interface LandingProps {
  updateModalContent: (content: React.ReactNode) => void;
  toggle: () => void;
  setModalType: (type: string) => void;
  items: ItemType[];
}

interface ItemType {
  img: string;
  name: string;
  desc: string;
  effect: string;
  price: number;
  lock: number;
  rac: number;
}

const Landing: React.FC<LandingProps> = ({
  updateModalContent,
  toggle,
  setModalType,
  items,
}) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isItemsShop, setIsItemsShop] = useState(false);
  const [isShowBoard, setShowBoard] = useState(false);
  const [coin, setCoin] = useState(22);
  const [hatImg, setHatImg] = useState("");
  const [modelImg, setModelImg] = useState("");
  const [neck, setNeck] = useState("");
  const [trust, setTrustImg] = useState(trustImg);
  const [trustText, setTrustText] = useState("");
  const [textColor, setTextColor] = useState("#AEAEAE");
  const [happiness, setHappinessImg] = useState("");
  const [error, setError] = useState<string | null>(null);
  const { connected, wallet, network, sender } = useTonConnect();
  const user = useSelector((state: any) => state.userData);
  const dispatch = useDispatch();
  const [happinessItem, setHappinessItem] = useState<React.ReactNode[]>([]);
  useEffect(() => {
    const authToken = localStorage.getItem("authToken");
    console.log("User state changed:", user);

    if (!authToken) {
      handleAuthorizeClick();
    }

    // Update hatImg based on user.hatType
    renderHat();
    switch (user.trust) {
      case 0:
        setTrustImg(trustImg);
        setTrustText("wary");
        setTextColor("#AEAEAE");
        break;
      case 1:
        setTrustImg(cautiousImg);
        setTrustText("cautious");
        setTextColor("#D7CD53");
        break;
      case 2:
        setTrustImg(friendlyImg);
        setTrustText("friendly");
        setTextColor("#94E0AE");
        break;
      case 3:
        setTrustImg(loyalImg);
        setTrustText("loyal");
        setTextColor("#58AEDD");
        break;
      case 4:
        setTrustImg(devotedImg);
        setTrustText("devoted");
        setTextColor("#6575F6");
        break;
    }

    var happinessImg = "";
    switch (user.happiness) {
      case 0:
        happinessImg = happinessImg0;
        break;
      case 1:
        happinessImg = happinessImg1;
        break;
      case 2:
        happinessImg = happinessImg2;
        break;
      case 3:
        happinessImg = happinessImg3;
        break;
      case 4:
        happinessImg = happinessImg4;
        break;
    }

    var list = [];
    for (let i = 0; i <= user.happiness; i++) {
      list.push(
        <i className="icon" key={i}>
          <img src={happinessImg} alt="tonIcon Img" />
        </i>
      );
    }
    setHappinessItem(list);
  }, [user]);

  const renderHat = () => {
    if (user.hatType > 0) {
      switch (user.hatType) {
        case 1:
          setHatImg(hatImg1);
          break;
        case 2:
          setHatImg(hatImg2);
          break;
        case 3:
          setHatImg(hatImg3);
          break;
        case 4:
          setHatImg(hatImg4);
          break;
      }
    }

    if (user.shirtType > 0) {
      switch (user.shirtType) {
        case 1:
          setModelImg(modelImg1);
          break;
        case 2:
          setModelImg(modelImg2);
          break;
        case 3:
          setModelImg(modelImg3);
          break;
      }
    }

    if (user.isNeck > 0) {
      setNeck(neckImg);
    }
  };

  const handleAuthorizeClick = async () => {
    setLoading(true);
    setError(null);

    try {
      const { initDataRaw } = retrieveLaunchParams();
      const response = await apiClient.post(
        "api/user/create",
        {
          initDataRaw,
          walletAddress: wallet,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `tma ${initDataRaw}`,
          },
        }
      );

      if (response.status !== 200) {
        throw new Error("Authorization failed");
      }

      const { user } = response.data;
      localStorage.setItem("authToken", initDataRaw || "");
      localStorage.setItem("isAdmin", user.role === "admin" ? "true" : "false");
      navigate("/welcome");
    } catch (error) {
      console.error("Error during authorization:", error);
      setError(
        "An error occurred during authorization: " + (error as Error).message
      );
    } finally {
      setLoading(false);
    }
  };

  const tapEarn = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // dispatch({ type: "SET_RAC", payload: user.racBalance + 1 });
      // setCoin((prev) => prev + 1);
    }, 1000);
  };

  const itemsShow = () => {
    setIsItemsShop((prev) => !prev);
  };

  const itemStatsShow = () => {
    setIsItemsShop((prev) => !prev);
  };

  const renderShowBoard = () => (
    <div className="h-[75.6vh] rounded-[15px] relative bg-[#252D52] items-box p-[20px] z-20">
      <button
        className="clos-btn z-30 absolute right-[15px] top-[15px]"
        onClick={() => {
          setShowBoard(false);
        }}
      >
        <svg
          width="16"
          height="16"
          viewBox="0 0 16 16"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M1.95098 0.334735C1.50467 -0.111578 0.781049 -0.111578 0.334735 0.334735C-0.111578 0.781049 -0.111578 1.50467 0.334735 1.95098L6.38376 8L0.334735 14.049C-0.111578 14.4953 -0.111578 15.219 0.334735 15.6653C0.781048 16.1116 1.50467 16.1116 1.95098 15.6653L8 9.61624L14.049 15.6653C14.4953 16.1116 15.219 16.1116 15.6653 15.6653C16.1116 15.219 16.1116 14.4953 15.6653 14.049L9.61624 8L15.6653 1.95098C16.1116 1.50467 16.1116 0.781049 15.6653 0.334735C15.219 -0.111578 14.4953 -0.111578 14.049 0.334735L8 6.38376L1.95098 0.334735Z"
            fill="#3E4867"
          />
        </svg>
      </button>
      <div className="title-area">
        <h1>
          <img src={lboard} alt="" className="mx-auto mb-[10px]" />
          <img src={board} alt="" className="mx-auto mb-[50px]" />
        </h1>
      </div>
      <div
        className="justify-between text-white text-[18px] w-full flex mb-[10px]"
        style={{ fontFamily: "Caros Regular" }}
      >
        <div className="w-[20%]">#</div>
        <div className="w-[60%]">Name</div>
        <div className="w-[20%]">Rac</div>
      </div>
      <div className="relative h-[45vh] overflow-y-auto">
        <div className="products-area">
          <div className="products-inner">
            {Board.map((item, index) => (
              <div
                className="px-[20px] py-[10px] rounded-[10px] mb-[10px]"
                style={{
                  background:
                    index == 0
                      ? "#6575F6"
                      : index == 1 || index == 2
                      ? "#6575F633"
                      : "#1C223F",
                }}
              >
                <div
                  className="justify-between text-white text-[17px] w-full flex"
                  style={{ fontFamily: "Caros Regular" }}
                >
                  <div className="w-[20%]">{item.rank}</div>
                  <div className="w-[60%]">{item.name}</div>
                  <div className="w-[20%]">{item.score}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderItemsShop = () => (
    <div className="tapbox items-box p-[20px] z-20">
      <button className="absolute right-[35px] z-30" onClick={itemsShow}>
        <img src={closebutton} alt="" />
      </button>
      <div className="title-area">
        <h1>
          <img src={itemTitle} alt="" className="mx-auto mb-[50px]" />
        </h1>
      </div>
      <div className="prodcuts-scroll-area relative">
        {/* {Item &&
          <div className='products-area'>
            <div className='products-inner'>
              {Item.map((item, index) => (
                <Button variant="primary" key={index} className={`products-box${!item.lock ? ' active' : ' disabled'}`} onClick={() => { 
                  setModalType('item'); 
                  updateModalContent(<ShopItemModal 
                    onClose={toggle} 
                    itemStatsShow={isItemsShop} 
                    item={{ 
                      ...item, 
                      desc: item.desc || '', // Provide a default value
                      effect: item.effect || '' // Provide a default value
                    }} 
                  />);
                }}>
                  <div>
                    <div className='img-box'>
                      <img src={item.img} alt="Product Image" />
                    </div>
                    <span className='absolute text-[10px] w-[100%] text-center left-[0px] bottom-[3px]'>{item.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        } */}
        {Item && (
          <div className="products-area">
            <div className="products-inner">
              {Item.map((item, index) => (
                <Button
                  variant="primary"
                  key={index}
                  className={`products-box${false ? " active" : " disabled"}`}
                  onClick={() => {
                    setModalType("item");
                    updateModalContent(
                      <ShopItemModal
                        onClose={toggle}
                        itemStatsShow={isItemsShop}
                        item={{
                          ...item,
                          desc: item.desc || "", // Provide a default value
                          effect: item.effect || "", // Provide a default value
                        }}
                      />
                    );
                  }}
                >
                  <div>
                    <div className="img-box">
                      {/* <img src={item.img} alt="Product Image" /> */}
                    </div>
                    {/* <span className='absolute text-[10px] w-[100%] text-center left-[0px] bottom-[3px]'>{item.name}</span> */}
                  </div>
                </Button>
              ))}
            </div>
          </div>
        )}
        <button
          className="save-btn mt-[50px] bottom-0 h-[59px] text-[20px]"
          style={{ fontFamily: "Caros Medium" }}
          onClick={itemStatsShow}
        >
          Save
        </button>
      </div>
    </div>
  );

  const renderMainContent = () => (
    <div className="tapbox z-10" style={{ backgroundColor: "rgb(28, 28, 30)" }}>
      <div
        className="title-area p-[20px]"
        style={{ backgroundColor: "rgb(28, 28, 30)" }}
      >
        {/* <img src={myRac} alt="racracIcon Img" /> */}
        <h1
          style={{
            fontFamily: "Caros Regular",
            color: "white",
            fontWeight: "bold",
          }}
        >
          LIMINAL RIPPLE
        </h1>
        <Link to="/" className="clos-btn">
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M1.95098 0.334735C1.50467 -0.111578 0.781049 -0.111578 0.334735 0.334735C-0.111578 0.781049 -0.111578 1.50467 0.334735 1.95098L6.38376 8L0.334735 14.049C-0.111578 14.4953 -0.111578 15.219 0.334735 15.6653C0.781048 16.1116 1.50467 16.1116 1.95098 15.6653L8 9.61624L14.049 15.6653C14.4953 16.1116 15.219 16.1116 15.6653 15.6653C16.1116 15.219 16.1116 14.4953 15.6653 14.049L9.61624 8L15.6653 1.95098C16.1116 1.50467 16.1116 0.781049 15.6653 0.334735C15.219 -0.111578 14.4953 -0.111578 14.049 0.334735L8 6.38376L1.95098 0.334735Z"
              fill="#3E4867"
            />
          </svg>
        </Link>
      </div>
      <div
        className="tapprice justify-between px-[20px]"
        style={{ backgroundColor: "rgb(28, 28, 30)" }}
      >
        <div className="tapprice-box">
          <p style={{ fontFamily: "Caros Regular" }}>Trust</p>
          <h3 className="justify-between">
            <i className="icon w-[30px]">
              <img src={trust} alt="tonIcon Img" />
            </i>
            <span
              className="text-[#AEAEAE] text-small text-[13px]"
              style={{ color: textColor, fontFamily: "Caros Regular" }}
            >
              {trustText}
            </span>
          </h3>
        </div>
        <div className="tapprice-box">
          <p style={{ fontFamily: "Caros Regular" }}>Happiness</p>
          <div className="flex">{happinessItem}</div>
        </div>
      </div>
      <div className="character-area pb-[20px]">
        <div className="relative flex items-center justify-center pb-[20px]">
          <img src={bg_rac} alt="groupBg Img" />
          {user.hatType > 0 ? (
            <div className="absolute top-[65px] z-10 w-[50px]">
              <img src={hatImg} />
            </div>
          ) : (
            ""
          )}
          {user.isNeck > 0 ? (
            <div className="absolute left-[130px] top-[205px] z-10 w-[30px]">
              <img src={neck} />
            </div>
          ) : (
            ""
          )}
          <button
            className="absolute mt-[60px] character-box1"
            onClick={tapEarn}
            disabled={loading}
          >
            <RaccoonCharacter />
            {/* {loading ? (
              <div className="charctor-show">
                <div
                  dangerouslySetInnerHTML={{
                    __html: `
                          <div
                              class="coin coin--animated"
                              style="--coin-to-x: calc(-200px + 24px); --coin-to-y: calc(-105px + 24px); --coin-delay: 0.3s;"
                            ></div>
                    `,
                  }}
                />
                {user.shirtType > 0 ? (
                  <img
                    src={modelImg}
                    alt="tonIcon Img"
                    className="w-[200px] h-[202px]"
                  />
                ) : (
                  <img
                    src={charctor2Image}
                    alt="tonIcon Img"
                    className="w-[200px] h-[202px]"
                  />
                )}
              </div>
            ) : (
              <div className="charctor-show">
                {user.shirtType > 0 ? (
                  <img
                    src={modelImg}
                    alt="tonIcon Img"
                    className="w-[200px] h-[202px]"
                  />
                ) : (
                  <img
                    src={charctor1Image}
                    alt="tonIcon Img"
                    className="w-[200px] h-[202px]"
                  />
                )}
              </div>
            )} */}
          </button>
          {/* <div
            className="absolute right-[20px] top-[10px]"
            onClick={() => updateModalContent(<FoodCome onClose={toggle} />)}
          >
            <img src={food} alt="" />
          </div> */}
        </div>
        {/* <div className="tapprice justify-between px-[20px]  bg-[#252D52]">
          <div className="tapprice-box">
            <p className="text-start" style={{ fontFamily: "Caros Regular" }}>
              Per Tap
            </p>
            <h3 style={{ fontFamily: "Caros Regular" }}>
              <i className="icon">
                <img src={rlogoImage} alt="tonIcon Img" />
              </i>
              1
            </h3>
          </div>
          <div className="tapprice-box">
            <p className="text-start" style={{ fontFamily: "Caros Regular" }}>
              Per Hour
            </p>
            <h3 style={{ fontFamily: "Caros Regular" }}>
              <i className="icon">
                <img src={rlogoImage} alt="tonIcon Img" />
              </i>
              140
            </h3>
          </div>
        </div> */}
        <div className="flex justify-center">
          <motion.div>
            <img src={rac} alt="racracImg" />
          </motion.div>
        </div>
        <div className="boost-area mt-[20px] px-[20px] flex justify-center">
          {/* Button 2 */}
          {/* <motion.button
            className="boost-btn bg-black"
            whileHover={{
              scale: 1.2,
              backgroundColor: "#0c0a09", // เปลี่ยนสีพื้นหลังเมื่อ Hover
            }}
            whileTap={{
              scale: 0.9,
            }}
            transition={{
              type: "spring",
              stiffness: 900,
              damping: 60,
            }}
          >
            RACRAC
          </motion.button> */}
        </div>
        <div>
          {/* Button 1 */}
          <motion.button
            // onClick={itemsShow}
            className="item-btn mr-[50px]"
            whileHover={{
              scale: 1.1, // ขยายเมื่อ Hover
              rotate: 5, // หมุนเล็กน้อยเมื่อ Hover
            }}
            whileTap={{
              scale: 0.9, // ลดขนาดเล็กน้อยเมื่อกด
            }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 20,
            }}
          >
            <img src={rib} alt="Rib Img" />
            {/* <svg
              width="21"
              height="21"
              viewBox="0 0 21 21"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M11.76 1.26C11.76 0.564121 11.1959 0 10.5 0C9.80412 0 9.24 0.564121 9.24 1.26V9.24H1.26C0.564121 9.24 0 9.80412 0 10.5C0 11.1959 0.564121 11.76 1.26 11.76H9.24V19.74C9.24 20.4359 9.80412 21 10.5 21C11.1959 21 11.76 20.4359 11.76 19.74V11.76H19.74C20.4359 11.76 21 11.1959 21 10.5C21 9.80412 20.4359 9.24 19.74 9.24H11.76V1.26Z"
                fill="white"
              />
            </svg> */}
          </motion.button>

          {/* Button 3 */}
          <motion.button
            // onClick={() => setShowBoard(!isShowBoard)}
            className="item-btn"
            whileHover={{
              scale: 1.1,
              rotate: -5,
            }}
            whileTap={{
              scale: 0.9,
            }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 20,
            }}
          >
            <img src={food} alt="Food Image" />
            {/* <svg
              width="24"
              height="21"
              viewBox="0 0 24 21"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M21.7065 2.93636H19.3647V1.85791C19.3647 1.09114 18.7191 0.467773 17.9266 0.467773H5.95125C5.15804 0.467773 4.51318 1.09114 4.51318 1.85791V2.93636H2.17139C1.37818 2.93636 0.733315 3.55973 0.733315 4.3265V4.91914C0.733315 7.3409 2.65049 9.33685 5.09446 9.56659C5.74538 10.9948 6.90795 12.1896 8.41338 12.8758C8.68737 13.0002 8.97196 13.1005 9.26109 13.189V15.8807H7.04267C6.58476 15.8807 6.17983 16.1632 6.03678 16.5824L4.54648 19.3169C4.43976 19.6278 4.49501 19.9724 4.69256 20.2387C4.89162 20.5051 5.21329 20.6638 5.55237 20.6638H18.3247C18.6638 20.6638 18.9855 20.5051 19.1845 20.2387C19.3828 19.9724 19.4373 19.6285 19.3306 19.3176L17.8403 16.5839C17.6973 16.1632 17.2923 15.8807 16.8344 15.8807H14.616V13.189C14.9051 13.1005 15.1897 13.0002 15.4637 12.8758C16.9692 12.1896 18.1325 10.9948 18.7826 9.56659C21.2266 9.33685 23.1438 7.3409 23.1438 4.91914V4.3265C23.1453 3.55973 22.4997 2.93636 21.7065 2.93636Z"
                fill="white"
              />
              <path
                d="M11.3977 4.0625H12.578V9.54332H11.2343V5.26828L10.3358 5.73415L9.83757 4.86896L11.3977 4.0625Z"
                fill="#313649"
              />
            </svg> */}
          </motion.button>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    if (isShowBoard) {
      return renderShowBoard();
    } else if (isItemsShop) {
      return renderItemsShop();
    } else {
      return renderMainContent();
    }
  };

  return (
    <div className="landing-screen">
      <div className="game-fit-screen">{renderContent()}</div>
    </div>
  );
};

const mapStateToProps = (state: { items: ItemType[] }) => ({
  items: state.items,
});

export default connect(mapStateToProps)(Landing);
