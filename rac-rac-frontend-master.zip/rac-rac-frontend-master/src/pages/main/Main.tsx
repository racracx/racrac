import apiClient from '../../api/axiosConfig';
import ReactDOM from "react-dom";
import React, { useState, useEffect } from "react";
import {
  Button,
  Modal,
  ModalBody,
  Popover,
  PopoverHeader,
  PopoverBody,
  Carousel,
  CarouselItem,
  CarouselControl,
  CarouselIndicators,
  CarouselCaption,
} from "reactstrap";
import { Link, useNavigate } from "react-router-dom";
import { useTonConnect } from "../../hooks/useTonConnect";
import { retrieveLaunchParams } from "@telegram-apps/sdk";
import { TonConnectButton, useTonConnectUI } from "@tonconnect/ui-react";

import "./Main.css";
import "bootstrap/dist/css/bootstrap.min.css";
import OpeningModal from "../../components/OpeningModal";
import ComeSoonModal from "../../components/ComeSoonModal";
import GetStarted from "../../components/GetStarted";

import racraclogo from "../../assets/images/Landing/RACRAC LOGO.png";
import setting from "../../assets/images/Landing/setting.png";
import rlogoImage from "../../assets/images/Landing/rlogo.png";
import tonIconImage from "../../assets/images/Landing/ton-icon.png";
import gif1 from "../../assets/images/Landing/ezgif-3-b12e495fd3.gif";
import raffleBanner from "../../assets/images/Landing/raffle-banner.png";
import raffleBanner1 from "../../assets/images/Landing/raffle-banner1.png";
import raffleBannerSVG from "../../assets/images/Landing/raffle-banner.svg";
import raffleBanner1SVG from "../../assets/images/Landing/raffle-banner1.svg";
import groupBg from "../../assets/images/Landing/group-bg.png";
import raffleButton from "../../assets/images/Landing/raffle-button.png";
import lottoButton from "../../assets/images/Landing/lotto-button.png";
import playButton from "../../assets/images/Landing/play-button.png";
import { connect } from "react-redux";
import { useDispatch, useSelector } from "react-redux";
import { ArrowBigDown } from "lucide-react";
import { loadComputeSkipReason } from "ton-core";

import hatImg1 from "../../assets/images/Landing/item/Layer_1 (1).png";
import hatImg2 from "../../assets/images/Landing/item/Layer_1 (3).png";
import hatImg3 from "../../assets/images/Landing/item/Layer_1 (7).png";
import hatImg4 from "../../assets/images/Landing/item/Layer_1 (8).png";

import modelImg1 from "../../assets/images/Landing/littlehero.png";
import modelImg2 from "../../assets/images/Landing/girlshirt.png";
import modelImg3 from "../../assets/images/Landing/racracshirt.png";

import neckImg from "../../assets/images/Landing/item/Group.png";
import ClaimButton from "../../components/ClaimButton";
import { motion } from "framer-motion";
import MotionWrapper from "../../components/MotionWrapper";
import RaccoonCharacter from "../../components/RaccoonCharacter";

interface MainProps {
  updateModalContent: (content: React.ReactNode) => void;
  toggle: () => void;
  setModalType: (type: string) => void;
}

const MainRegular: React.FC<MainProps> = ({
  updateModalContent,
  toggle,
  setModalType,
}) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [countPage, setCountPage] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [isClaimAnimation, setIsClaimAnimation] = useState(false);
  const { connected, wallet, network, sender } = useTonConnect();
  const [showStartButton, setShowStartButton] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const user = useSelector((state: any) => state.userData);
  const [hatImg, setHatImg] = useState("");
  const [modelImg, setModelImg] = useState("");
  const [neck, setNeck] = useState("");
  const dispatch = useDispatch();
  useEffect(() => {
    console.log("use effect....");
    renderHat();

    const simulateData = async () => {
      try {
        const response = await apiClient.post(
          "http://localhost:3000/getUserByName",
          { query: "sunlight757" },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        dispatch({ type: "SET_USER", payload: response.data });
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    simulateData();

    const interval = setInterval(() => {
      next();
    }, 3000); // Auto-slide interval in milliseconds

    return () => clearInterval(interval);
  }, [dispatch]); // Only re-run if dispatch changes (which it shouldn't)

  useEffect(() => {
    if (connected && wallet) {
      setShowStartButton(true);
    } else {
      setShowStartButton(false);
    }
  }, [connected, wallet]); // Only re-run if connected or wallet changes

  const renderHat = () => {
    if (user.hatType > 0) {
      switch (user.hatType) {
        case 1:
          setHatImg(hatImg1);
          break;
        case 2:
          setHatImg(hatImg2);
          break;
        case 3:
          setHatImg(hatImg3);
          break;
        case 4:
          setHatImg(hatImg4);
          break;
      }
    }

    if (user.shirtType > 0) {
      switch (user.shirtType) {
        case 1:
          setModelImg(modelImg1);
          break;
        case 2:
          setModelImg(modelImg2);
          break;
        case 3:
          setModelImg(modelImg3);
          break;
      }
    }

    if (user.isNeck > 0) {
      setNeck(neckImg);
    }
  };

  const newItemsSlider = {
    dots: true,
    infinite: true,
    prevArrow: false,
    nextArrow: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    ArrowBigDown,
  };

  const rewardSlider = {
    dots: true,
    infinite: true,
    prevArrow: false,
    nextArrow: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    ArrowBigDown,
  };

  const items = [
    {
      src: raffleBannerSVG,
      altText: "Slide 1",
      caption: "raffle",
    },
    {
      src: raffleBanner1SVG,
      altText: "Slide 2",
      caption: "item",
    },
  ];
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);

  const next = () => {
    if (animating || isModalOpen) return;
    const nextIndex = activeIndex === items.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(nextIndex);
  };

  const previous = () => {
    if (animating || isModalOpen) return;
    const nextIndex = activeIndex === 0 ? items.length - 1 : activeIndex - 1;
    setActiveIndex(nextIndex);
  };

  const goToIndex = (newIndex: number) => {
    if (animating || isModalOpen) return;
    setActiveIndex(newIndex);
  };

  const handleAnimationClaim = () => {
    console.log("getDailyReward");
    console.log(user);
    if (!user.getDailyReward) {
      navigate("/task");
    } else {
      return;
    }
  };

  const handleAuthorizeClick = async () => {
    setLoading(true);
    setError(null);

    try {
      const { initDataRaw } = retrieveLaunchParams();

      console.log("initDataRaw:", initDataRaw);

      const response = await apiClient.post(
        "api/user/create",
        {
          initDataRaw,
          walletAddress: wallet,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `tma ${initDataRaw}`,
          },
        }
      );
      console.log("********response", response);
      if (response.status !== 200) {
        throw new Error("Authorization failed");
      }

      const { user } = response.data;
      console.log("********user", user);

      localStorage.setItem("authToken", initDataRaw!);
      localStorage.setItem("isAdmin", user.role === "admin" ? "true" : "false");
      navigate("/welcome");
    } catch (error) {
      console.error("Error during authorization:", error);
      setError(
        "An error occurred during authorization: " + (error as Error).message
      );
    } finally {
      setLoading(false);
    }
  };

  const openModal = (param: string) => {
    console.log(param);
    setIsModalOpen(true);
    setModalType(param);
    switch (param) {
      case "started":
        updateModalContent(<GetStarted onClose={toggle} />);
        break;
      case "raffle":
        updateModalContent(<OpeningModal onClose={toggle} />);
        break;
      case "lotto":
        updateModalContent(<ComeSoonModal onClose={toggle} />);
        break;
      // case 'spindialog':
      //   updateModalContent(<SpinDialog onClose={toggle} />);
      //   break;
    }
  };

  const toggleModal = () => openModal("spindialog");

  const slides = items.map((item, index) => {
    return (
      <CarouselItem
        onExiting={() => setAnimating(true)}
        onExited={() => setAnimating(false)}
        key={item.src}
      >
        <img
          src={item.src}
          alt={item.altText}
          className="d-block justify-center h-auto pl-[10px]"
          onClick={item.caption === "raffle" ? toggleModal : undefined}
        />
      </CarouselItem>
    );
  });

  return (
    <div className="landing-screen main-screen">
      <div className="game-fit-screen" style={{ background: "#0D0D0D", fontFamily: "Caros Regular" }}>
        <div className="race-raflle" >
          <Carousel
            activeIndex={activeIndex}
            next={next}
            previous={previous}
            enableTouch={true}
          >
            {slides}
          </Carousel>
        </div>
        <div className="tapbox" onClick={() => navigate("/landing")}>
          <div className="relative flex items-center justify-center">
            <img src={groupBg} alt="groupBg Img" className="mt-[20px]" />

            <button className="absolute mt-[60px] character-box1">
              {/* <RaccoonCharacter /> */}
            </button>
          </div>
        </div>
        {/* <div className="claim-daily p-[10px] bg-[#252D52] rounded-lg mt-[15px]">
          <div className="flex justify-between">
            <span className="text-white text-sm leading-[28px] pr-[10px]">
              Claim your daily goodies!
            </span>
            <ClaimButton
              onClick={handleAnimationClaim}
              text="Claim"
              style={{
                border: "2px solid #FF69B4", // เพิ่มเส้นขอบ
                borderRadius: "12px", // ทำให้ขอบมนเพิ่ม
                padding: "5px 10px", // ปรับ Padding
              }}
            />
            <button
              className="button px-[15px] rounded-lg py-[3px] text-sm"
              style={{
                background: user.getDailyReward ? "#1A2035" : "#EA56D1",
                color: user.getDailyReward ? "#3E4867" : "#fff",
              }}
              onClick={handleAnimationClaim}
            >
              Claim!
            </button>
          </div>
        </div> */}
        <div className="flex justify-between mt-[20px]">
          {/* Raffle Button */}
          <MotionWrapper
            className="raffleButton"
            onClick={() => openModal("raffle")}
          >
            <img src={raffleButton} alt="Raffle Button" />
          </MotionWrapper>

          {/* Lotto Button */}
          <MotionWrapper
            className="lottoButton"
            onClick={() => openModal("lotto")}
          >
            <img src={lottoButton} alt="Lotto Button" />
          </MotionWrapper>

          {/* Play Button */}
          <MotionWrapper className="playButton">
            <img src={playButton} alt="Play Button" />
          </MotionWrapper>
        </div>
        {/* <div className="flex justify-between mt-[20px]">
          <div className="raffleButton" onClick={() => openModal("raffle")}>
            <img src={raffleButton} alt="" />
          </div>
          <div className="lottoButton" onClick={() => openModal("lotto")}>
            <img src={lottoButton} alt="" />
          </div>
          <div className="playButton">
            <img src={playButton} alt="" />
          </div>
        </div> */}
      </div>
    </div>
  );
};

export default MainRegular;
