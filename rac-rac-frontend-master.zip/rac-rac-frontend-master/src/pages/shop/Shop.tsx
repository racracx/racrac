import apiClient from '../../api/axiosConfig';
import React, { useState, useEffect, ReactNode } from "react";
import {
  Button,
  Modal,
  ModalBody,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
} from "reactstrap";
import { Link, useNavigate } from "react-router-dom";
import { useTonConnectUI } from "@tonconnect/ui-react";
import { useTonConnect } from "../../hooks/useTonConnect";

import "./Shop.css";
import "bootstrap/dist/css/bootstrap.min.css";
import ShopProductModal from "../../components/shopProductModal";
import { Food } from "../../assets/products/shopProducts";
import { Item } from "../../assets/products/shopProducts";
import { Magic } from "../../assets/products/shopProducts";
import { Rac } from "../../assets/products/shopProducts";
import ShopItemBuyModal from "../../components/ShopItemBuyModal";
import ShopRacModal from "../../components/ShopRacModal";
import racraclogo from "../../assets/images/Landing/RACRAC LOGO.png";
import rlogoImage from "../../assets/images/Landing/rlogo.png";
import FoodCome from "../../components/FoodCome";

import tonIconImage from "../../assets/images/Landing/ton-icon.png";
import productImage1 from "../../assets/images/Landing/product-1.png";
import productImage2 from "../../assets/images/Landing/product-2.png";
import emptyProduct from "../../assets/images/Landing/emptyproduct.png";
import lockItem from "../../assets/images/Landing/lock-item.png";
import closebutton from "../../assets/images/btn-close-round.svg";
import banner2 from "../../assets/images/Landing/Task Page Banner.png";
import banner3 from "../../assets/images/Landing/Task Page Banner (1).png";
import banner1 from "../../assets/images/Landing/Task Page Banner (2).png";
import banner2SVG from "../../assets/images/Landing/Task Page Banner.svg";
import banner3SVG from "../../assets/images/Landing/Task Page Banner (1).svg";
import banner1SVG from "../../assets/images/Landing/Task Page Banner (2).svg";
import { totalmem } from "os";
import NotEnoughRACModal from "../../components/NotEnoughRACModal";
import NotEnoughTONModal from "../../components/NotEnoughTONModal";
import { motion } from "framer-motion";
import MotionWrapper from "../../components/MotionWrapper";

interface ShopProps {
  updateModalContent: (content: React.ReactNode) => void;
  toggle: () => void;
  setModalType: (type: string) => void;
}

interface RacItem {
  img: string;
  rac: number;
  price: number;
  lock: number;
}

const Shop: React.FC<ShopProps> = ({
  updateModalContent,
  toggle,
  setModalType,
}) => {
  const navigate = useNavigate();
  const { connected, wallet } = useTonConnect();
  const [tonConnectUI, setOptions] = useTonConnectUI();
  const [activeTab, setActiveTab] = useState<string>("1");
  const [isClaimAnimation, setIsClaimAnimation] = useState<boolean>(false);
  const [isClaimAnimation1, setIsClaimAnimation1] = useState<boolean>(false);
  const [isClaimAnimation2, setIsClaimAnimation2] = useState<boolean>(false);

  const toggleTab = (tab: string) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const handleAnimationClaim = () => {
    setIsClaimAnimation(true);
  };

  const handleAnimationClaim1 = () => {
    setIsClaimAnimation1(true);
  };

  const handleAnimationClaim2 = () => {
    setIsClaimAnimation2(true);
  };

  const selectRac = () => {
    toggle();
    setActiveTab("3");
  };

  const selectWallet = () => {
    toggle();
    navigate("/profile");
  };

  const enough = () => {
    updateModalContent(
      <NotEnoughRACModal onClose={toggle} selectRac={selectRac} />
    );
  };

  const notEnoughTon = () => {
    updateModalContent(
      <NotEnoughTONModal onClose={toggle} selectWallet={selectWallet} />
    );
  };

  return (
    <div className="landing-screen shop-screen" style={{ fontFamily: "Caros Regular" }}>
      <div className="game-fit-screen">
        <div className="tapbox">
          <Link to="/" className="absolute right-[35px] mt-[10px]">
            <img src={closebutton} alt="" />
          </Link>
          <div className="banner">
            {activeTab == "1" && (
              <img src={banner1SVG} className="rounded-t-lg w-full" />
            )}
            {activeTab == "2" && (
              <img src={banner2SVG} className="rounded-t-lg w-full" />
            )}
            {activeTab == "3" && (
              <img src={banner3SVG} className="rounded-t-lg w-full" />
            )}
          </div>
          <Nav
            tabs
            style={{
              backgroundColor: "#1C1C1E", // เปลี่ยนสีพื้นหลังหลัก
              position: "relative",
              fontFamily: "Caros Regular"
            }}
          >
            {/* เส้นแสดงตำแหน่ง Tab ที่เลือก */}
            <div
              style={{
                position: "absolute",
                top: 5, // เส้นอยู่ใต้ข้อความ
                left: `calc(${((parseInt(activeTab) - 1) * 88) / 3}% + 20%)`, // เลื่อนเส้นให้ตรงกลาง Tab
                height: "3px", // ความสูงของเส้น
                width: "15%", // ลดความกว้างเส้น
                backgroundColor: "#6575F6", // สีเส้น
                transform: "translateX(-50%)", // จัดให้อยู่กึ่งกลางของ Tab
                transition: "left 0.3s ease, width 0.3s ease", // ทำให้นุ่มนวลเมื่อเปลี่ยน Tab
              }}
            />
            <div
              style={{
                position: "absolute",
                top: 5, // เส้นอยู่ใต้ข้อความ
                height: "3px", // ความสูงของเส้น
                width: "90%", // ความกว้างของเส้น
                backgroundColor: "#6575F640", // สีเด่นชัด
                transform: "translateX(0%)", // จัดให้อยู่กึ่งกลางของ Tab
              }}
            />
            <NavItem>
              <MotionWrapper>
                <NavLink
                  className={activeTab === "1" ? "active" : ""}
                  style={{
                    color:
                      activeTab === "1"
                        ? "#6575F6"
                        : "rgba(101, 117, 246, 0.4)", // เปลี่ยนสีตามสถานะ
                    fontWeight: activeTab === "1" ? "bold" : "normal", // เพิ่มตัวหนา
                    transition: "color 0.3s ease, font-weight 0.3s ease", // ทำให้การเปลี่ยนสีและความหนานุ่มนวล
                    fontFamily: "Caros Regular"
                  }}
                  onClick={() => {
                    toggleTab("1");
                  }}
                >
                  Food
                </NavLink>
              </MotionWrapper>
            </NavItem>
            <NavItem>
              <MotionWrapper>
                <NavLink
                  className={activeTab === "2" ? "active" : ""}
                  onClick={() => {
                    toggleTab("2");
                  }}
                  style={{
                    color:
                      activeTab === "2"
                        ? "#6575F6"
                        : "rgba(101, 117, 246, 0.4)", // เปลี่ยนสีตามสถานะ
                    fontWeight: activeTab === "2" ? "bold" : "normal", // เพิ่มตัวหนา
                    transition: "color 0.3s ease, font-weight 0.3s ease", // ทำให้การเปลี่ยนสีและความหนานุ่มนวล
                    fontFamily: "Caros Regular"
                  }}
                >
                  Items
                </NavLink>
              </MotionWrapper>
            </NavItem>
            <NavItem>
              <MotionWrapper>
                <NavLink
                  className={activeTab === "3" ? "active" : ""}
                  onClick={() => {
                    toggleTab("3");
                  }}
                  style={{
                    color:
                      activeTab === "3"
                        ? "#6575F6"
                        : "rgba(101, 117, 246, 0.4)", // เปลี่ยนสีตามสถานะ
                    fontWeight: activeTab === "3" ? "bold" : "normal", // เพิ่มตัวหนา
                    transition: "color 0.3s ease, font-weight 0.3s ease", // ทำให้การเปลี่ยนสีและความหนานุ่มนวล
                    fontFamily: "Caros Regular"
                  }}
                >
                  Magic
                </NavLink>
              </MotionWrapper>
            </NavItem>
            <TabContent
              activeTab={activeTab}
              style={{
                backgroundColor: "#1C1C1E", // เปลี่ยนสีพื้นหลังหลัก
                fontFamily: "Caros Regular"
              }}
            >
              <TabPane tabId="1" className="award-panel">
                <div className="parent-award">
                  {Food.map((item, index) => (
                    <MotionWrapper
                      className="p-[20px] rounded-[10px] bg-[#0D0D0D] relative flex justify-center items-center"
                      onClick={() =>
                        updateModalContent(<FoodCome onClose={toggle} />)
                      }
                    >
                      {!item.lock ? (
                        <>
                          <img
                            src={item.img}
                            alt=""
                            className="h-[37px] m-auto block"
                          />
                          {/* <p className="text-white text-[10px] text-center w-full absolute left-[0px] bottom-[10px]">
                            {item.name}
                          </p> */}
                        </>
                      ) : (
                        <img src={lockItem} className="m-auto p-[15px] block" />
                      )}
                    </MotionWrapper>
                  ))}
                </div>
              </TabPane>
              <TabPane tabId="2" className="award-panel">
                <div className="parent-award">
                  {Item.map((item, index) => (
                    <MotionWrapper
                      key={index} // เพิ่ม key ให้กับแต่ละรายการ
                      className="p-[20px] rounded-[10px] bg-[#0D0D0D] relative flex justify-center items-center"
                      onClick={
                        () => updateModalContent(<FoodCome onClose={toggle} />)
                        // updateModalContent(
                        //   <ShopItemBuyModal
                        //     onClose={toggle}
                        //     src={item.img}
                        //     name={item.name}
                        //     enough={enough}
                        //   />
                        // )
                      }
                    >
                      {!item.lock ? (
                        <>
                          <img
                            src={item.img}
                            alt=""
                            className="h-[37px] m-auto block"
                          />
                          {/* <p className="text-white text-[10px] text-center w-full absolute left-[0px] bottom-[10px]">
                            {item.name}
                          </p> */}
                        </>
                      ) : (
                        <img src={lockItem} className="m-auto p-[15px] block" />
                      )}
                    </MotionWrapper>
                  ))}
                </div>
              </TabPane>
              <TabPane tabId="3" className="award-panel">
                <div className="parent-award">
                  {Magic.map((item, index) => (
                    <MotionWrapper
                      key={index} // เพิ่ม key ให้กับแต่ละรายการ
                      className="p-[20px] rounded-[10px] bg-[#0D0D0D] relative flex justify-center items-center"
                      onClick={
                        () => updateModalContent(<FoodCome onClose={toggle} />)
                        // updateModalContent(
                        //   <ShopItemBuyModal
                        //     onClose={toggle}
                        //     src={item.img}
                        //     name={item.name}
                        //     enough={enough}
                        //   />
                        // )
                      }
                    >
                      {!item.lock ? (
                        <>
                          <img
                            src={item.img}
                            alt=""
                            className="h-[37px] m-auto block"
                          />
                          {/* <p className="text-white text-[10px] text-center w-full absolute left-[0px] bottom-[10px]">
                            {item.name}
                          </p> */}
                        </>
                      ) : (
                        <img src={lockItem} className="m-auto p-[15px] block" />
                      )}
                    </MotionWrapper>
                  ))}
                  {/* {Rac.filter((item) => item.rac !== undefined).map(
                    (item, index) => (
                      <MotionWrapper
                        key={index}
                        className="p-[20px] rounded-[10px] bg-[#0D0D0D] relative"
                        onClick={() =>
                          updateModalContent(
                            <ShopRacModal
                              onClose={toggle}
                              racItem={item}
                              notEnoughTon={notEnoughTon}
                            />
                          )
                        }
                      >
                        {!item.lock ? (
                          <>
                            <img
                              src={item.img}
                              alt=""
                              className="h-[37px] m-auto block"
                            />
                            <p className="text-white text-[15px] text-center w-full absolute left-[0px] bottom-[10px] price">
                              {item.rac}
                            </p>
                          </>
                        ) : (
                          <img src={lockItem} className="m-auto p-[15px] block" />
                        )}
                      </MotionWrapper>
                    )
                  )} */}
                </div>
              </TabPane>
            </TabContent>
            {!connected && (
              <button
                onClick={() => tonConnectUI.connectWallet()}
                className="bg-[#6575F6] w-full py-[14px] px-[20px] rounded-b-lg text-start text-white"
                style={{ fontFamily: "Caros Regular" }}
              >
                Connect Wallet
              </button>
            )}
          </Nav>
        </div>
      </div>
    </div>
  );
};

export default Shop;
