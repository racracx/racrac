import accessoriesProdcut1 from "../images/Landing/accessories-prodcut-1.png";
import topProducts1 from "../images/Landing/top-product-1.png";
import emptyProduct from "../images/Landing/emptyproduct.png";
import marshmallowImg from "../images/Landing/item/Layer_1 (9).png";
import baconImg from "../images/Landing/item/Layer_1 (10).png";
import honeyImg from "../images/Landing/item/Group 235688.png";
import beerImg from "../images/Landing/item/Layer_1 (11).png";
import rac1Img from "../images/Landing/item/5K Rac 1.png";
import rac2Img from "../images/Landing/item/10K Rac 1.png";
import rac3Img from "../images/Landing/item/50K Rac 1.png";
import rac4Img from "../images/Landing/item/100K Rac 1.png";
import rac5Img from "../images/Landing/item/200K Rac 1.png";
import rac6Img from "../images/Landing/item/5K Rac 1.png";
import lastAutumnLeafImg from "../images/last-autumn-leaf.svg";
import departureStickImg from "../images/departure-stick.svg";
import littleHerosShirtImg from "../images/little-heros-shirt.svg";
import kindGirlsShirtImg from "../images/kind-girls-shirt.svg";
import racracTeeImg from "../images/racrac-tee.svg";
import origamiBirdImg from "../images/origami-bird.svg";
import wishwornCandleImg from "../images/wishworn-candle.svg";
import sunnyShellCharmImg from "../images/sunny-shell-charm.svg";
import lockImg from "../images/last-autumn-leaf.svg";
import exp from "constants";

// Define types for the products (optional but recommended for clarity)
interface Product {
    image?: string;
    isImageProduct: boolean;
    isComingSoon: boolean;
    isLock: boolean;
    isActive: boolean;
    fontFamily?: string;
  }

  export const Food = [
    {
      img: marshmallowImg,
      name: 'Marshmallow',
      desc: "Marsh-melmel is Rac's all-time favorite food! He first tried it straight from your fridge.",
      effect: '+35% Happiness',
      price: 100000,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: baconImg,
      name: 'Bacon',
      desc: "Leftover bacon is often found near diner trash bins",
      effect: '+5% Happiness',
      price: 100000,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: honeyImg,
      name: 'Honey',
      desc: "Pure, raw honey crafted by friendly bees.",
      effect: '+25% Happiness',
      price: 100000,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: beerImg,
      name: 'Beer',
      desc: "Rac once tried it at the open bar, felt a weird joy, and absolutely loved it!",
      effect: '+50% Happiness',
      price: 100000,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: rac1Img,
      price: 100000,
      lock: 1,
      fontFamily: "Caros Regular"
    },
    {
      img: rac2Img,
      price: 100000,
      lock: 1,
      fontFamily: "Caros Regular"
    },
  ]
  export const Rac = [
    {
      img: rac1Img,
      rac: 100000,
      price: 3,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: rac2Img,
      rac: 300000,
      price: 6,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: rac3Img,
      rac: 500000,
      price: 10,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: rac4Img,
      rac: 800000,
      price: 16,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: rac5Img,
      rac: 1000000,
      price: 20,
      lock: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: rac6Img,
      price: 100000,
      lock: 1,
      fontFamily: "Caros Regular"
    },
  ]
  export const Item = [
    {
      img: littleHerosShirtImg,
      name: 'Little Hero’s Shirt',
      desc: "Tossed aside after countless playtimes. Once Rac wears it, he feels like a tiny adventurer himself. ",
      effect: '+20% Per Tap | +0% Per Hour',
      price: 50000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: kindGirlsShirtImg,
      name: 'Kind Girl’s Shirt',
      desc: "Once belonging to a five-year- old girl. Faded cupcake-patterned with soft fabric and sweet scent. ",
      effect: '+0% Per Tap | +20% Per Hour',
      price: 50000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: racracTeeImg,
      name: 'RACRAC Tee',
      desc: "Recycled Cotton, produced by RACRAC Team for your Rac.",
      effect: '+5% Per Tap | +1% Per Hour',
      price: 500000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: origamiBirdImg,
      name: 'Origami Bird',
      desc: "Standard A4 paper, folded by the neighbor kindergarten boy. ",
      effect: '+10% Per Tap | +3% Per Hour',
      price: 500000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: wishwornCandleImg,
      name: 'Wishworn Candle',
      desc: "Though small and used, it holds the warmth of joy, laughter, and dreams, with a soft flicker still remaining. ",
      effect: '+20% Per Tap | +7% Per Hour',
      price: 1000000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: sunnyShellCharmImg,
      name: 'Sunny Shell Charm',
      desc: "A tiny shell from a girl’s summer beach trip, dropped in her backyard, Rac loves its cool touch against his fur.",
      effect: '+10% Per Tap | +3% Per Hour',
      price: 3000000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
  ];
  export const Magic = [
    {
      img: lastAutumnLeafImg,
      name: 'Last Autumn Leaf',
      desc: "A brown leaf from the autumn Rac left his Tanuki clan, a reminder of his magical home. ",
      effect: '+10% Per Tap | +5% Per Hour',
      price: 10000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: departureStickImg,
      name: 'Departure Stick',
      desc: "A branch found after leaving his Tanuki clan on his first journey, symbolizing new beginnings ",
      effect: '+5% Per Tap | +10% Per Hour',
      price: 10000,
      lock: 0,
      rac: 0,
      fontFamily: "Caros Regular"
      
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
    {
      img: lockImg,
      name: 'lock',
      price: 1000,
      lock: 1,
      rac: 0,
      fontFamily: "Caros Regular"
    },
  ];

  export const Award = [
    {
      daily: 1,
      award: 100,
      fontFamily: "Caros Regular"
    },
    {
      daily: 2,
      award: 150,
      fontFamily: "Caros Regular"
    },
    {
      daily: 3,
      award: 200,
      fontFamily: "Caros Regular"
    },
    {
      daily: 4,
      award: 250 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 5,
      award: 300 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 6,
      award: 350 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 7,
      award: 400 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 8,
      award: 450 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 9,
      award: 500 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 10,
      award: 550 ,
      fontFamily: "Caros Regular"
    },
    {
      daily: 11,
      award: 600 ,
      fontFamily: "Caros Regular"
    },{
      daily: 12,
      award: 700 ,
      fontFamily: "Caros Regular"
    },
    // ,{
    //   daily: 13,
    //   award: 50,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 14,
    //   award: 50,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 15,
    //   award: 50,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 16,
    //   award: 60,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 17,
    //   award: 60,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 18,
    //   award: 60,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 19,
    //   award: 70,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 20,
    //   award: 70,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 21,
    //   award: 70,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 22,
    //   award: 80,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 23,
    //   award: 80,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 24,
    //   award: 80,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 25,
    //   award: 90,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 26,
    //   award: 90,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 27,
    //   award: 90,
      // fontFamily: "Caros Regular"
    // },,{
    //   daily: 28,
    //   award: 100,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 29,
    //   award: 100,
      // fontFamily: "Caros Regular"
    // },
    // ,{
    //   daily: 30,
    //   award: 100,
      // fontFamily: "Caros Regular"
    // },
  ]

  export const Board = [
    {
      rank: 1,
      name: 'Player X',
      score: 999,
      fontFamily: "Caros Regular"
    },
    {
      rank: 2,
      name: 'Player X',
      score: 998,
      fontFamily: "Caros Regular"
    },
    {
      rank: 3,
      name: 'Player X',
      score: 997,
      fontFamily: "Caros Regular"
    },
    {
      rank: 4,
      name: 'Player X',
      score: 996,
      fontFamily: "Caros Regular"
    },
    {
      rank: 5,
      name: 'Player X',
      score: 995,
      fontFamily: "Caros Regular"
    },
    {
      rank: 6,
      name: 'Player X',
      score: 994,
      fontFamily: "Caros Regular"
    },
    {
      rank: 7,
      name: 'Player X',
      score: 993,
      fontFamily: "Caros Regular"
    },
    {
      rank: 8,
      name: 'Player X',
      score: 992,
      fontFamily: "Caros Regular"
    },
    {
      rank: 9,
      name: 'Player X',
      score: 991,
      fontFamily: "Caros Regular"
    },
    {
      rank: 10,
      name: 'Player X',
      score: 990,
      fontFamily: "Caros Regular"
    },
  ]

  export const SHOP_PRODUCTS = {
    topProducts: [
      {
        image: topProducts1,
        isImageProduct: true,
        isComingSoon: false,
        isLock: false,
        isActive: true,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
    ],
    shoesProducts: [
      {
        isImageProduct: false,
        isComingSoon: true,
        isLock: false,
        isActive: false,
        image: '' ,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        image: '' ,
        fontFamily: "Caros Regular"
  
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        image: '' ,
        fontFamily: "Caros Regular"
  
      },
    ],
    accessoriesProducts: [
      {
        image: accessoriesProdcut1,
        isImageProduct: true,
        isComingSoon: false,
        isLock: false,
        isActive: true,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
    ],
    decorationsProducts: [
      {
        image: emptyProduct,
        isImageProduct: true,
        isComingSoon: false,
        isLock: false,
        isActive: true,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
      {
        isImageProduct: false,
        isComingSoon: false,
        isLock: true,
        isActive: false,
        fontFamily: "Caros Regular"
      },
    ] as Product[],
  };
