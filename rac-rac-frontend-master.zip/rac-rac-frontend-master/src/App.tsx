import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate } from "react-router-dom";
import "@twa-dev/sdk";
import styled from "styled-components";

// Components
import BottomNav from './components/BottomNavigation';
import CustomModal from './components/CustomModal';
import Header from './components/Header';
import WebApp from '@twa-dev/sdk'

// Pages
import SplashScreen from "./pages/splash/SplashScreen";
import Landing from './pages/landing/Landing';
import Profile from './pages/profile/Profile';
import Shop from './pages/shop/Shop';
import Task from './pages/task/Task';
import MainRegular from './pages/main/Main';

// Hooks
import { useTonConnect } from "./hooks/useTonConnect";
import { useDispatch, useSelector } from 'react-redux';
import { retrieveLaunchParams } from '@telegram-apps/sdk';

// API
import apiClient from './api/axiosConfig';

// Styles
import "./App.css";

const StyledApp = styled.div`
  background-color: #0D0D0D;
  color: white;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`;

const AppContainer = styled.div`
  flex: 1;
  max-width: 100%;
  padding: 23px 20px;

  ${({ $isBlurred }: { $isBlurred?: boolean }) => $isBlurred && `
    filter: blur(9px);
    pointer-events: none; // Prevents interaction with blurred content
  `}
`;

const SplashOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
`;

const App: React.FC = () => {
  const navigate = useNavigate();
  const { network } = useTonConnect();
  const [showSplash, setShowSplash] = useState<boolean>(true);

  const { initDataRaw, initData } = retrieveLaunchParams();

  const toggleModal = () => setIsOpen(prevState => !prevState);
  const closeModal = () => setIsOpen(false);
  const [modalContent, setModalContent] = useState<React.ReactNode>(<p></p>);
  const [modalType, setModalType] = useState<string>('null');
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const dispatch = useDispatch();

  const userId = initData?.user?.id
  const startParam = initData?.startParam

  const updateModalContent = (content: React.ReactNode) => {
    setModalContent(content);
    setIsOpen(true); // Optionally open the modal when content is updated
  };

  useEffect(() => {
    const SPLASH_DURATION = 2000; // 2 seconds
    const timer = setTimeout(() => {
      setShowSplash(false);
      navigate('/task')
    }, SPLASH_DURATION);

    WebApp.ready();
    WebApp.expand();
    WebApp.disableVerticalSwipes();
    WebApp.setBackgroundColor("#0D0D0D");
    WebApp.setHeaderColor("#0D0D0D");

    const loadData = async () => {
      try {
        const response = await apiClient.get('/api/users/profile', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${initDataRaw}`,
          },
        });
        dispatch({ type: 'SET_USER', payload: response.data });
      } catch (error) {
        console.error('Error loading data:', error);
      }
    };

    const checkReferral = async () => {
      if (startParam && userId) {
        try {
          await apiClient.post('/api/users/referrals',
            { userId: userId, referrerId: startParam },
            {
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${initDataRaw}`,
              }
            });
        } catch (error) {
          console.error('Error saving referral:', error);
        }
      }
    }

    loadData();
    checkReferral()

    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      <StyledApp>
        <AppContainer $isBlurred={showSplash}>
          <Header />
          <Routes>
            <Route path="/" element={<MainRegular updateModalContent={updateModalContent} toggle={closeModal} setModalType={setModalType} />} />
            <Route path="/landing" element={<Landing updateModalContent={updateModalContent} toggle={closeModal} setModalType={setModalType} />} />
            <Route path="/profile" element={<Profile updateModalContent={updateModalContent} toggle={closeModal} setModalType={setModalType} />} />
            <Route path="/shop" element={<Shop updateModalContent={updateModalContent} toggle={closeModal} setModalType={setModalType} />} />
            <Route path="/task" element={<Task updateModalContent={updateModalContent} toggle={closeModal} setModalType={setModalType} />} />
          </Routes>
          <BottomNav />
        </AppContainer>
        {showSplash && (<SplashOverlay><SplashScreen /></SplashOverlay>)}
        <CustomModal isOpen={isOpen} toggle={toggleModal} modalType={modalType}>
          {modalContent}
        </CustomModal>
      </StyledApp>
    </div>
  );
};

export default App;
