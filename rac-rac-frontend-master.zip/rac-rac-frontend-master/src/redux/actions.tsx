// src/redux/actions.tsx
export const BUY_ITEM = 'BUY_ITEM';
export const BUY_RAC = 'BUY_RAC';
export const SET_CONTINUELOGIN = 'SET_CONTINUELOGIN';
export const SET_DAILYREWARD = 'SET_DAILYREWARD';
export const SET_HAPPINESS = 'SET_HAPPINESS';
export const SET_HAT = 'SET_HAT';
export const SET_NECK = 'SET_NECK';
export const SET_RAC = 'SET_RAC';
export const SET_SHIRT = 'SET_SHIRT';
export const SET_TON = 'SET_TON';
export const SET_TRUST = 'SET_TRUST';
export const SET_USER = 'SET_USER';

export const buyItem = (item: []) => ({ type: BUY_ITEM, payload: item });
export const buyRac = (rac: number) => ({ type: BUY_RAC, payload: rac });
export const setHat = (hatType: number) => ({ type: SET_HAT, payload: hatType });
export const setShirt = (shirtType: number) => ({ type: SET_SHIRT, payload: shirtType });
export const setNeck = (isNeck: boolean) => ({ type: SET_NECK, payload: isNeck });
export const setRac = (rac: number) => ({ type: SET_RAC, payload: rac });
export const setTon = (ton: number) => ({ type: SET_TON, payload: ton });
export const setTrust = (trust: number) => ({ type: SET_TRUST, payload: trust });
export const setHappiness = (happiness: number) => ({ type: SET_HAPPINESS, payload: happiness });
export const setDailyReward = (dailyReward: boolean) => ({ type: SET_DAILYREWARD, payload: dailyReward });
export const setContinueLogin = (continueLogin: number) => ({ type: SET_CONTINUELOGIN, payload: continueLogin });
export const setUser = (user: any) => ({ type: SET_USER, payload: user });
