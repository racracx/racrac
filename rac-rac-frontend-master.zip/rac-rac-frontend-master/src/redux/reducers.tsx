// src/redux/reducers.tsx
import { BUY_ITEM, BUY_RAC, SET_CONTINUELOGIN, SET_DAILYREWARD, SET_HAPPINESS, SET_HAT, SET_NECK, SET_RAC, SET_SHIRT, SET_TON, SET_TRUST, SET_USER } from './actions';

const initialState = {
  items: [] as { racBalance: number; tonBalance: number; }[],
  userData: {
    hatType: 0,
    isNeck: 0,
    shirtType: 0,
    racBalance: 0,
    tonBalance: 0,
    trust: 0,
    happiness: 0,
    getDailyReward: false,
    loginStreakCount: 0,
  },
};

const itemReducer = (state = initialState, action: { type: string; payload: any; }) => {
  switch (action.type) {
    case BUY_ITEM:
      return {
        ...state,
        items: [...state.items, action.payload],
      };
    case BUY_RAC:
      return {
        ...state,
        userData: {
          ...state.userData,
          racBalance: state.userData.racBalance + action.payload.racBalance,
          tonBalance: state.userData.tonBalance - action.payload.tonBalance,
        },
      };
    case SET_HAT:
      return {
        ...state,
        userData: {
          ...state.userData,
          hatType: action.payload,
        },
      };
    case SET_SHIRT:
      return {
        ...state,
        userData: {
          ...state.userData,
          shirtType: action.payload,
        },
      };
    case SET_NECK:
      return {
        ...state,
        userData: {
          ...state.userData,
          isNeck: action.payload,
        },
      };
    case SET_RAC:
      return {
        ...state,
        userData: {
          ...state.userData,
          racBalance: action.payload,
        },
      };
    case SET_TON:
      return {
        ...state,
        userData: {
          ...state.userData,
          tonBalance: action.payload,
        },
      };
    case SET_TRUST:
      return {
        ...state,
        userData: {
          ...state.userData,
          trust: action.payload,
        },
      };
    case SET_HAPPINESS:
      return {
        ...state,
        userData: {
          ...state.userData,
          happiness: action.payload,
        },
      };
    case SET_CONTINUELOGIN:
      return {
        ...state,
        userData: {
          ...state.userData,
          loginStreakCount: action.payload,
        },
      };
    case SET_DAILYREWARD:
      return {
        ...state,
        userData: {
          ...state.userData,
          getDailyReward: action.payload,
        },
      };
    case SET_USER:
      return {
        ...state,
        userData: {
          ...state.userData,
          ...action.payload,
          getDailyReward: formatFirebaseTimestamp(action.payload.lastRewardClaimed) === today()
        }
      };
    default:
      return state;
  }
};

// Function to get today's date in 'YYYY-MM-DD' format
const today = (): string => {
  const date = new Date();
  return date.toISOString().split('T')[0];
};

// Function to convert Firebase Timestamp or Date to 'YYYY-MM-DD' format
const formatFirebaseTimestamp = (timestamp: any): string => {
  if (!timestamp || typeof timestamp._seconds !== 'number') {
    console.error("Invalid timestamp format");
    return '';
  }
  
  const date = new Date(timestamp._seconds * 1000); // Convert seconds to milliseconds
  return date.toISOString().split('T')[0];
};

export default itemReducer;
